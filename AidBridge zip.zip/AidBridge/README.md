# AidBridge: Post-Disaster Relief Camp & Resource Management Portal

**Master of Computer Applications (MCA) Academic Mini-Project**  
A full-stack disaster recovery web portal built with **Python, Django, PostgreSQL / SQLite, and Bootstrap 5**.

---

## 1. Project Overview & Objectives

**AidBridge** is designed for the critical **post-disaster recovery phase** following natural calamities such as **floods, landslides, and cyclones**. 

The system provides:
1. **Centralized Relief Camp Administration**: Monitor maximum bed capacities, assign residents safely without exceeding occupancy, track available amenities, and compute real-time vacancies (`Remaining = Max - Occupancy`).
2. **Transparent Supply Shortage Tracking**: Automatic deficit calculations (`Shortage = Required - Received`) for essential food, drinking water, medicine, blankets, and hygiene kits.
3. **Atomic Donation Verification**: One-click donation verification by camp administrators that credits camp stock inventories and decrements supply shortages atomically.
4. **Proximity Camp Discovery**: Built-in mathematical **Haversine Distance Formula** enabling affected citizens to find the closest relief shelters using GPS coordinates.
5. **Rehabilitation & Missing Persons Bureau**: Searchable register of verified displaced persons with emergency helplines.
6. **Real-time Emergency Broadcasting**: High-priority alert banner ticker and personal notification dispatch.

---

## 2. Key Modules

### Module 1 — Admin Portal (`/admin-portal/`)
- **Executive Command Dashboard**: 8 real-time database counters and dynamic **Chart.js** visualizations.
- **Relief Camp Management**: Establish, edit, and deactivate camps with capacity enforcement.
- **Camp Resident Management**: Admit victims, track special medical conditions, and manage discharges.
- **Resource & Stock Control**: Post camp-specific supply targets, view live shortage deficits, and inspect on-hand physical stock.
- **Donation Verification Engine**: Review and verify donations with automatic inventory credit.
- **Missing Persons Bureau**: Review citizen reports, verify identities, and mark individuals as located.
- **Broadcast System**: Dispatch emergency advisories to all citizens or specific recipients.
- **Operations Audit & Reports**: Tabular data tables with filtering and a print-ready PDF audit layout.

### Module 2 — Public & Citizen Portal
- **Home & Live Impact**: Disaster statistics, emergency alert ticker, urgent resource requirements preview.
- **Camp Directory**: Search by name/district, filter by status, and sort by GPS proximity using the Haversine formula.
- **Resource Board**: Transparent progress meters showing received supplies vs remaining shortages.
- **Missing Persons Directory**: Public-safe search interface with photo records.
- **Authentication**: Secure registration and login with single-click demo credential filling.

---

## 3. Technology Stack

- **Backend**: Python 3.13 + Django 5.x
- **Database**: PostgreSQL (Production) / SQLite3 (Zero-setup development fallback)
- **Frontend**: HTML5, CSS3, Bootstrap 5.3, Bootstrap Icons
- **Visualizations**: Chart.js 4.x
- **Mathematics**: Haversine Great-Circle Distance Algorithm

---

## 4. Demo Login Credentials (For Viva / Evaluation)

The system comes pre-seeded with accounts and sample data:

| Role | Username / Email | Password | Access Level |
| :--- | :--- | :--- | :--- |
| **Relief Administrator** | `admin@aidbridge.org` (or `admin`) | `admin123` | Full Admin Portal (`/admin-portal/`) & Django Admin (`/django-admin/`) |
| **Affected Citizen** | `citizen@aidbridge.org` (or `citizen`) | `user123` | Public Services, Reports & Notices |

*(On the login page, you can click the **"Fill Admin"** or **"Fill Citizen"** buttons to auto-populate credentials instantly during demonstrations).*

---

## 5. Local Setup Instructions (Windows)

### Step 1: Open Terminal and Navigate to Project
```powershell
cd C:\Users\madha\.gemini\antigravity\scratch\AidBridge
```

### Step 2: Create and Activate Virtual Environment (Optional but Recommended)
```powershell
python -m venv venv
.\venv\Scripts\Activate.ps1
```

### Step 3: Install Required Dependencies
```powershell
pip install -r requirements.txt
```

### Step 4: Apply Database Migrations
```powershell
python manage.py makemigrations
python manage.py migrate
```

### Step 5: Seed Demo Data
Populates the database with the Admin account, Citizen account, 3 realistic relief camps (with GPS coordinates), sample residents, resource requirements, donations, missing persons, and announcements:
```powershell
python manage.py seed_data
```

### Step 6: Start the Development Server
```powershell
python manage.py runserver
```

Open your web browser and navigate to:
- **Public Portal**: [http://127.0.0.1:8000/](http://127.0.0.1:8000/)
- **Admin Control Center**: [http://127.0.0.1:8000/admin-portal/](http://127.0.0.1:8000/admin-portal/)
- **Django Native Admin**: [http://127.0.0.1:8000/django-admin/](http://127.0.0.1:8000/django-admin/)

---

## 6. PostgreSQL Setup (Production or pgAdmin)

To switch from SQLite to PostgreSQL:

1. Create a database in PostgreSQL / pgAdmin:
   ```sql
   CREATE DATABASE aidbridge_db;
   ```
2. Set environment variables (or create a `.env` file from `.env.example`):
   ```env
   DB_ENGINE=postgresql
   DB_NAME=aidbridge_db
   DB_USER=postgres
   DB_PASSWORD=your_password
   DB_HOST=localhost
   DB_PORT=5432
   ```
3. Run migrations and seed data:
   ```powershell
   python manage.py migrate
   python manage.py seed_data
   ```

A standalone SQL schema is also available in `sql/schema.sql`.

---

## 7. Docker Deployment

To run with Docker and Docker Compose (starts Django + PostgreSQL together):
```bash
docker-compose up --build
```
Access the application at [http://localhost:8000](http://localhost:8000).

---

## 8. Project Structure

```
AidBridge/
├── manage.py                          # Django management script
├── requirements.txt                   # Project dependencies
├── README.md                          # Project documentation and setup guide
├── PROJECT_DOCUMENTATION.md           # Formal MCA academic project documentation
├── Dockerfile                         # Container build configuration
├── docker-compose.yml                 # Multi-container orchestration (App + PostgreSQL)
├── sql/
│   └── schema.sql                     # PostgreSQL-compatible DDL relational schema
├── aidbridge/                         # Django project configuration
│   ├── settings.py                    # Settings (PostgreSQL/SQLite fallback, Auth, Static)
│   ├── urls.py                        # Root URL routing
│   ├── wsgi.py                        # WSGI server interface
│   └── asgi.py                        # ASGI server interface
└── core/                              # Main application module
    ├── models.py                      # Relational models (Camp, Resident, Resource, Donation, etc.)
    ├── forms.py                       # Form validation and Bootstrap widgets
    ├── views.py                       # Public portals and auth views
    ├── admin_views.py                 # Administrative control center & CRUD workflows
    ├── urls.py                        # Core application URLs
    ├── admin.py                       # Django standard ORM admin configuration
    ├── utils.py                       # Haversine distance, metrics aggregator, permission guards
    ├── context_processors.py          # Global badges and notification counters
    ├── management/commands/
    │   └── seed_data.py               # One-command database seeder
    ├── static/
    │   ├── css/style.css              # Disaster relief styling
    │   └── js/main.js                 # Geolocation, Haversine sorting, demo helpers
    └── templates/                     # HTML5 templates
        ├── base.html                  # Public layout with navigation
        ├── home.html                  # Public homepage with live metrics
        ├── about.html                 # MCA project academic overview
        ├── camps_public.html          # Camp directory with proximity distance
        ├── resources_public.html      # Live supply shortages board
        ├── missing_public.html        # Missing persons directory
        ├── notifications_public.html  # Emergency bulletins
        ├── auth/                      # Login & Register templates
        └── admin/                     # Full Admin Module templates
            ├── admin_base.html        # Admin layout with sidebar
            ├── dashboard.html         # Live metrics & Chart.js
            ├── camps/                 # Relief camps CRUD
            ├── users/                 # User management & toggle active
            ├── residents/             # Resident admission & capacity guard
            ├── resources/             # Resource requirements & stock
            ├── donations/             # Donation verification workflow
            ├── missing_persons/       # Missing persons cases
            ├── notifications/         # Broadcast creation
            └── reports/               # Operational audit tables & printable report
```
