"""
AidBridge Public Views & Authentication
Provides public portals, nearby camp discovery with Haversine distance, and user auth.
"""
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout
from django.contrib import messages
from django.db.models import Sum, Q
from django.http import JsonResponse

from .models import (
    ReliefCamp, ResourceRequirement, MissingPerson, 
    Notification, Donation, CampResident, User
)
from .forms import UserLoginForm, UserRegistrationForm
from .utils import haversine_distance


def home(request):
    """
    Public Home Page: Live disaster recovery metrics, urgent needs, and quick actions.
    """
    total_camps = ReliefCamp.objects.count()
    active_camps = ReliefCamp.objects.filter(status='ACTIVE').count()
    total_sheltered = CampResident.objects.filter(status='APPROVED').count()
    total_donations_verified = Donation.objects.filter(status='VERIFIED').count()
    urgent_needs = ResourceRequirement.objects.filter(status='URGENT').select_related('camp')[:6]
    recent_announcements = Notification.objects.filter(
        user__isnull=True, 
        notification_type='ANNOUNCEMENT'
    ).order_by('-created_at')[:4]

    context = {
        'total_camps': total_camps,
        'active_camps': active_camps,
        'total_sheltered': total_sheltered,
        'total_donations_verified': total_donations_verified,
        'urgent_needs': urgent_needs,
        'recent_announcements': recent_announcements,
    }
    return render(request, 'home.html', context)


def about(request):
    """
    About AidBridge: Objectives, MCA Project Architecture, and Disaster Recovery Lifecycle.
    """
    return render(request, 'about.html')


def camps_public(request):
    """
    Public Directory of Relief Camps with search, district filters,
    and Haversine distance calculation relative to citizen's GPS coordinates.
    """
    query = request.GET.get('q', '').strip()
    district_filter = request.GET.get('district', '').strip()
    status_filter = request.GET.get('status', '').strip()
    user_lat = request.GET.get('lat', '').strip()
    user_lng = request.GET.get('lng', '').strip()

    camps = ReliefCamp.objects.all()

    if query:
        camps = camps.filter(
            Q(name__icontains=query) | 
            Q(address__icontains=query) | 
            Q(facilities__icontains=query)
        )
    if district_filter:
        camps = camps.filter(district__iexact=district_filter)
    if status_filter:
        camps = camps.filter(status=status_filter)

    # Convert to list and compute distance if coordinates provided
    camps_list = []
    for camp in camps:
        camp_data = {
            'obj': camp,
            'distance': None,
        }
        if user_lat and user_lng:
            dist = haversine_distance(user_lat, user_lng, camp.latitude, camp.longitude)
            camp_data['distance'] = dist
        camps_list.append(camp_data)

    if user_lat and user_lng:
        camps_list.sort(key=lambda x: (x['distance'] is None, x['distance']))

    districts = ReliefCamp.objects.values_list('district', flat=True).distinct()

    context = {
        'camps_list': camps_list,
        'districts': districts,
        'selected_district': district_filter,
        'selected_status': status_filter,
        'query': query,
        'user_lat': user_lat,
        'user_lng': user_lng,
    }
    return render(request, 'camps_public.html', context)


def resources_public(request):
    """
    Transparent view of required vs received relief supplies across camps.
    """
    camp_id = request.GET.get('camp', '').strip()
    status_filter = request.GET.get('status', '').strip()

    requirements = ResourceRequirement.objects.select_related('camp').all()

    if camp_id:
        requirements = requirements.filter(camp_id=camp_id)
    if status_filter:
        requirements = requirements.filter(status=status_filter)

    camps = ReliefCamp.objects.filter(status__in=['ACTIVE', 'FULL'])

    context = {
        'requirements': requirements,
        'camps': camps,
        'selected_camp': camp_id,
        'selected_status': status_filter,
    }
    return render(request, 'resources_public.html', context)


def missing_persons_public(request):
    """
    Searchable directory of verified missing persons with safe public information.
    """
    query = request.GET.get('q', '').strip()
    gender = request.GET.get('gender', '').strip()
    status_filter = request.GET.get('status', '').strip()

    persons = MissingPerson.objects.all()

    if query:
        persons = persons.filter(
            Q(name__icontains=query) | 
            Q(last_known_location__icontains=query) |
            Q(description__icontains=query)
        )
    if gender:
        persons = persons.filter(gender=gender)
    if status_filter:
        persons = persons.filter(status=status_filter)

    context = {
        'persons': persons,
        'query': query,
        'selected_gender': gender,
        'selected_status': status_filter,
    }
    return render(request, 'missing_public.html', context)


def notifications_public(request):
    """
    Public Announcements and citizen-specific alerts.
    """
    announcements = Notification.objects.filter(user__isnull=True).order_by('-created_at')
    user_notifications = []
    if request.user.is_authenticated:
        user_notifications = Notification.objects.filter(user=request.user).order_by('-created_at')

    context = {
        'announcements': announcements,
        'user_notifications': user_notifications,
    }
    return render(request, 'notifications_public.html', context)


def login_view(request):
    """
    Authentication handler supporting username or email.
    """
    if request.user.is_authenticated:
        if request.user.is_admin_user():
            return redirect('admin_dashboard')
        return redirect('home')

    form = UserLoginForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        user = form.cleaned_data['user']
        login(request, user)
        messages.success(request, f"Welcome back, {user.get_full_name() or user.username}!")
        
        # Check next redirect or route according to role
        next_url = request.GET.get('next')
        if next_url:
            return redirect(next_url)
        if user.is_admin_user():
            return redirect('admin_dashboard')
        return redirect('home')

    return render(request, 'auth/login.html', {'form': form})


def register_view(request):
    """
    Citizen registration view.
    """
    if request.user.is_authenticated:
        return redirect('home')

    form = UserRegistrationForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        user = form.save()
        login(request, user)
        messages.success(
            request, 
            f"Account created successfully! Welcome to AidBridge, {user.first_name}."
        )
        return redirect('home')

    return render(request, 'auth/register.html', {'form': form})


def logout_view(request):
    """
    Log out view.
    """
    logout(request)
    messages.info(request, "You have been logged out safely.")
    return redirect('home')


# Error handlers
def custom_403_view(request, exception=None):
    return render(request, '403.html', status=403)

def custom_404_view(request, exception=None):
    return render(request, '404.html', status=404)

def custom_500_view(request):
    return render(request, '500.html', status=500)
