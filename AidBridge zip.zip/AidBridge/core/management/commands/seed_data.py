"""
AidBridge Sample Data Seeder
Populates initial administrator, citizen accounts, camps, residents,
resource requirements, donations, missing persons, and notifications.
"""
from django.core.management.base import BaseCommand
from django.utils import timezone
from core.models import (
    User, ReliefCamp, CampResident, ResourceRequirement, 
    ResourceInventory, Donation, MissingPerson, Notification
)


class Command(BaseCommand):
    help = 'Seeds realistic sample data for the AidBridge MCA Mini Project'

    def handle(self, *args, **options):
        self.stdout.write(self.style.NOTICE("Initializing AidBridge database seeder..."))

        # 1. Administrator Account
        admin_user, created = User.objects.get_or_create(
            username='admin',
            defaults={
                'email': 'admin@aidbridge.org',
                'first_name': 'Dr. Rajesh',
                'last_name': 'Nambiar',
                'phone': '+91 98470 99999',
                'address': 'State Disaster Management Authority HQ, Trivandrum',
                'role': 'ADMIN',
                'user_status': 'ACTIVE',
                'is_staff': True,
                'is_superuser': True,
            }
        )
        if created:
            admin_user.set_password('admin123')
            admin_user.save()
            self.stdout.write(self.style.SUCCESS("Created Admin: admin@aidbridge.org / admin123"))
        else:
            admin_user.set_password('admin123')
            admin_user.role = 'ADMIN'
            admin_user.is_staff = True
            admin_user.is_superuser = True
            admin_user.save()
            self.stdout.write("Updated Admin credentials.")

        # 2. Citizen Account
        citizen_user, created = User.objects.get_or_create(
            username='citizen',
            defaults={
                'email': 'citizen@aidbridge.org',
                'first_name': 'Ananya',
                'last_name': 'Menon',
                'phone': '+91 94471 22334',
                'address': 'Chundale Post, Vythiri, Wayanad',
                'role': 'CITIZEN',
                'user_status': 'ACTIVE',
            }
        )
        if created:
            citizen_user.set_password('user123')
            citizen_user.save()
            self.stdout.write(self.style.SUCCESS("Created Citizen: citizen@aidbridge.org / user123"))
        else:
            citizen_user.set_password('user123')
            citizen_user.save()

        # 3. Relief Camps
        camps_data = [
            {
                'name': 'Wayanad Valley Flood Relief Camp',
                'address': 'St. Mary Higher Secondary School Campus, Meppadi',
                'district': 'Wayanad',
                'state': 'Kerala',
                'latitude': 11.554200,
                'longitude': 76.126400,
                'capacity': 250,
                'contact': '+91 98470 11223',
                'facilities': 'Safe Drinking Water, 24/7 Medical Station, Community Kitchen, Hygiene Kits, Bedding, Power Generator, Pediatric Care',
                'status': 'ACTIVE',
            },
            {
                'name': 'Coastal Cyclone Emergency Shelter',
                'address': 'Multipurpose Cyclone Shelter Complex, Marine Drive',
                'district': 'Puri',
                'state': 'Odisha',
                'latitude': 19.813500,
                'longitude': 85.831200,
                'capacity': 300,
                'contact': '+91 94370 44556',
                'facilities': 'Reinforced Storm Dome, Sanitation Units, Infant Formula, Clean Water RO, First Aid Ward, Satellite Radio',
                'status': 'ACTIVE',
            },
            {
                'name': 'Chamoli Landslide Rehabilitation Center',
                'address': 'Government Inter College Grounds, Pipalkoti',
                'district': 'Chamoli',
                'state': 'Uttarakhand',
                'latitude': 30.412100,
                'longitude': 79.330800,
                'capacity': 120,
                'contact': '+91 97580 77889',
                'facilities': 'Heated Blankets, Warm Meals Mess, Trauma Counseling, Orthopedic Aid, Emergency Ambulance',
                'status': 'ACTIVE',
            }
        ]

        camps = []
        for cdata in camps_data:
            camp, _ = ReliefCamp.objects.update_or_create(
                name=cdata['name'],
                defaults=cdata
            )
            camps.append(camp)
        self.stdout.write(self.style.SUCCESS(f"Populated {len(camps)} Relief Camps with GPS coordinates."))

        # 4. Camp Residents
        residents_data = [
            {
                'camp': camps[0],
                'name': 'Suresh Kumar',
                'age': 45,
                'gender': 'Male',
                'phone': '+91 98460 55667',
                'emergency_contact': 'Priya (Wife) - +91 98460 55668',
                'address': 'Chooralmala Hamlet, Wayanad',
                'medical_information': 'Type-2 Diabetic, Requires Daily Metformin',
                'status': 'APPROVED',
            },
            {
                'camp': camps[0],
                'name': 'Priya Suresh',
                'age': 42,
                'gender': 'Female',
                'phone': '+91 98460 55668',
                'emergency_contact': 'Suresh (Husband) - +91 98460 55667',
                'address': 'Chooralmala Hamlet, Wayanad',
                'medical_information': 'Asthma, Carries Inhaler',
                'status': 'APPROVED',
            },
            {
                'camp': camps[0],
                'name': 'Advaith Kumar',
                'age': 11,
                'gender': 'Male',
                'phone': '',
                'emergency_contact': 'Suresh Kumar (Father)',
                'address': 'Chooralmala Hamlet, Wayanad',
                'medical_information': 'Minor abrasions treated on admission',
                'status': 'APPROVED',
            },
            {
                'camp': camps[1],
                'name': 'Subhashree Behera',
                'age': 28,
                'gender': 'Female',
                'phone': '+91 94390 12345',
                'emergency_contact': 'Manas Behera (Brother) - +91 94390 54321',
                'address': 'Pentakotta Fishermen Colony, Puri',
                'medical_information': 'Third trimester pregnancy, prenatal checkup needed',
                'status': 'APPROVED',
            },
            {
                'camp': camps[2],
                'name': 'Devendra Rawat',
                'age': 67,
                'gender': 'Male',
                'phone': '+91 97580 33221',
                'emergency_contact': 'Kailash Rawat (Son) - +91 97580 99887',
                'address': 'Joshimath Ward 4, Chamoli',
                'medical_information': 'Hypertension, Arthritis (needs lower bunk)',
                'status': 'APPROVED',
            }
        ]

        for rdata in residents_data:
            CampResident.objects.get_or_create(
                camp=rdata['camp'],
                name=rdata['name'],
                defaults=rdata
            )
        
        # Trigger occupancy recount on all camps
        for c in camps:
            c.update_occupancy_from_residents()

        self.stdout.write(self.style.SUCCESS("Populated Camp Residents and recalculated camp occupancy."))

        # 5. Resource Requirements
        requirements_data = [
            {
                'camp': camps[0],
                'resource_name': 'Drinking Water (Bottled)',
                'required_quantity': 1000,
                'received_quantity': 650,
                'unit': 'Liters',
                'status': 'MODERATE',
            },
            {
                'camp': camps[0],
                'resource_name': 'Thermal Blankets',
                'required_quantity': 200,
                'received_quantity': 120,
                'unit': 'Pieces',
                'status': 'MODERATE',
            },
            {
                'camp': camps[0],
                'resource_name': 'Paracetamol 500mg & ORS',
                'required_quantity': 150,
                'received_quantity': 40,
                'unit': 'Packs',
                'status': 'URGENT',
            },
            {
                'camp': camps[1],
                'resource_name': 'Food Rice (Dry Rations)',
                'required_quantity': 500,
                'received_quantity': 350,
                'unit': 'Kg',
                'status': 'MODERATE',
            },
            {
                'camp': camps[1],
                'resource_name': 'Sanitary Hygiene Kits',
                'required_quantity': 180,
                'received_quantity': 60,
                'unit': 'Kits',
                'status': 'URGENT',
            },
            {
                'camp': camps[2],
                'resource_name': 'Infant Milk Formula',
                'required_quantity': 80,
                'received_quantity': 20,
                'unit': 'Tins',
                'status': 'URGENT',
            }
        ]

        created_reqs = []
        for reqdata in requirements_data:
            req, _ = ResourceRequirement.objects.update_or_create(
                camp=reqdata['camp'],
                resource_name=reqdata['resource_name'],
                defaults=reqdata
            )
            created_reqs.append(req)

            # Pre-seed available inventory stock corresponding to received
            ResourceInventory.objects.update_or_create(
                camp=req.camp,
                resource_name=req.resource_name,
                defaults={
                    'available_quantity': req.received_quantity,
                    'unit': req.unit
                }
            )

        self.stdout.write(self.style.SUCCESS("Populated Resource Requirements and Inventories."))

        # 6. Sample Donations (Some Verified, Some Pending for Admin Action)
        donations_data = [
            {
                'donor': citizen_user,
                'camp': camps[0],
                'resource_requirement': created_reqs[0],
                'resource_name': 'Drinking Water (Bottled)',
                'quantity': 100,
                'unit': 'Liters',
                'donor_name': 'Ananya Menon',
                'donor_phone': '+91 94471 22334',
                'message': 'Dispatched via Kerala Transport truck, driver Mohan.',
                'status': 'VERIFIED',
                'verified_at': timezone.now(),
                'verified_by': admin_user,
            },
            {
                'donor': None,
                'camp': camps[0],
                'resource_requirement': created_reqs[1],
                'resource_name': 'Thermal Blankets',
                'quantity': 30,
                'unit': 'Pieces',
                'donor_name': 'Rotary Club Cochin Central',
                'donor_phone': '+91 98460 77112',
                'message': 'Arriving at camp gate today afternoon.',
                'status': 'PENDING',  # Ready for immediate demo verification!
            },
            {
                'donor': None,
                'camp': camps[1],
                'resource_requirement': created_reqs[4],
                'resource_name': 'Sanitary Hygiene Kits',
                'quantity': 50,
                'unit': 'Kits',
                'donor_name': 'Odisha Youth Relief Volunteer Wing',
                'donor_phone': '+91 94370 88990',
                'message': 'Direct delivery by local college students.',
                'status': 'PENDING',  # Ready for immediate demo verification!
            }
        ]

        for ddata in donations_data:
            Donation.objects.get_or_create(
                camp=ddata['camp'],
                resource_name=ddata['resource_name'],
                quantity=ddata['quantity'],
                defaults=ddata
            )
        self.stdout.write(self.style.SUCCESS("Populated Donations (including pending verification items for demo)."))

        # 7. Missing Persons
        missing_data = [
            {
                'reporter': citizen_user,
                'reporter_name': 'Ananya Menon',
                'reporter_phone': '+91 94471 22334',
                'name': 'Gopalan Nair',
                'age': 72,
                'gender': 'Male',
                'last_known_location': 'Tea Plantation Staff Quarters, Chooralmala',
                'description': 'Height 5 ft 6 in, white hair, was wearing a light blue shirt and white dhoti. Walks with a slight limp.',
                'status': 'VERIFIED',
            },
            {
                'reporter': None,
                'reporter_name': 'Manoj Patra',
                'reporter_phone': '+91 94371 66554',
                'name': 'Debashish Patra',
                'age': 16,
                'gender': 'Male',
                'last_known_location': 'Balighai Beach Road, Puri',
                'description': 'Height 5 ft 8 in, athletic build, black t-shirt and jeans, carrying a blue backpack during cyclone evacuation.',
                'status': 'MISSING',
            },
            {
                'reporter': None,
                'reporter_name': 'Meena Devi',
                'reporter_phone': '+91 97580 11223',
                'name': 'Sarita Devi',
                'age': 35,
                'gender': 'Female',
                'last_known_location': 'Helang Roadside Market, Chamoli',
                'description': 'Height 5 ft 2 in, red shawl and yellow salwar. Was separated during landslide road blockage.',
                'status': 'LOCATED',
            }
        ]

        for mdata in missing_data:
            MissingPerson.objects.get_or_create(
                name=mdata['name'],
                last_known_location=mdata['last_known_location'],
                defaults=mdata
            )
        self.stdout.write(self.style.SUCCESS("Populated Missing Persons records."))

        # 8. Emergency Notifications & Broadcasts
        notifications_data = [
            {
                'user': None,  # Global Broadcast
                'title': 'High Inflow Alert: Kabini & Banasura Sagar Dam Gates Raised',
                'message': 'Citizens in low-lying riparian zones of Wayanad are advised to relocate to St. Mary Relief Camp immediately. Transport shuttles are operating from Meppadi junction.',
                'notification_type': 'ANNOUNCEMENT',
            },
            {
                'user': None,  # Global Broadcast
                'title': 'Urgent Call: Pediatric Formula and Blankets Needed',
                'message': 'Chamoli Landslide Rehabilitation Center has received 15 displaced infants. Donations of baby formula and warm woolens are requested on priority.',
                'notification_type': 'ANNOUNCEMENT',
            },
            {
                'user': citizen_user,
                'title': 'Donation Verified and Received',
                'message': 'Your pledge of 100 Liters Drinking Water for Wayanad Valley Flood Relief Camp has been received and credited to active distribution inventory.',
                'notification_type': 'DONATION',
            }
        ]

        for ndata in notifications_data:
            Notification.objects.get_or_create(
                title=ndata['title'],
                defaults=ndata
            )
        self.stdout.write(self.style.SUCCESS("Populated Announcements and Alerts."))
        self.stdout.write(self.style.SUCCESS(">>> AidBridge Sample Data Seed Complete! <<<"))
