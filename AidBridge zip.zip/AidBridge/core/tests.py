"""
AidBridge Comprehensive Test Suite
Validates mathematical calculations, models, business logic constraints,
atomic donation verification, Haversine formula, and view security.
"""
from django.test import TestCase, Client
from django.urls import reverse
from django.core.exceptions import ValidationError
from django.db import transaction

from core.models import (
    User, ReliefCamp, CampResident, ResourceRequirement,
    ResourceInventory, Donation, MissingPerson, Notification
)
from core.utils import haversine_distance


class HaversineFormulaTestCase(TestCase):
    def test_known_distance(self):
        # Wayanad coordinates to Kozhikode coordinates (~65-75 km)
        lat1, lon1 = 11.6854, 76.1320
        lat2, lon2 = 11.2588, 75.7804
        dist = haversine_distance(lat1, lon1, lat2, lon2)
        self.assertIsNotNone(dist)
        self.assertTrue(50 < dist < 90, f"Distance should be around 65-75km, got {dist}")

    def test_zero_distance_for_same_point(self):
        dist = haversine_distance(11.0, 76.0, 11.0, 76.0)
        self.assertEqual(dist, 0.0)


class ReliefCampLogicTestCase(TestCase):
    def setUp(self):
        self.camp = ReliefCamp.objects.create(
            name="Test Rescue Shelter",
            address="123 River Road",
            district="Wayanad",
            state="Kerala",
            latitude=11.5,
            longitude=76.1,
            capacity=100,
            occupancy=0,
            contact="+91 99999 11111",
            facilities="Water, Food, Medical",
            status="ACTIVE"
        )

    def test_remaining_capacity_calculation(self):
        self.assertEqual(self.camp.remaining_capacity, 100)
        
        # Add approved resident
        CampResident.objects.create(
            camp=self.camp,
            name="Ravi Kumar",
            age=35,
            gender="Male",
            emergency_contact="Sister - 9876543210",
            status="APPROVED"
        )
        self.camp.refresh_from_db()
        self.assertEqual(self.camp.occupancy, 1)
        self.assertEqual(self.camp.remaining_capacity, 99)
        self.assertEqual(self.camp.occupancy_percentage, 1.0)


class ResourceAndDonationAtomicTestCase(TestCase):
    def setUp(self):
        self.admin_user = User.objects.create_user(
            username="testadmin",
            email="admin@test.com",
            password="adminpassword",
            role="ADMIN"
        )
        self.citizen = User.objects.create_user(
            username="testcitizen",
            email="citizen@test.com",
            password="userpassword",
            role="CITIZEN"
        )
        self.camp = ReliefCamp.objects.create(
            name="Delta Cyclone Camp",
            address="Coast Road",
            district="Puri",
            state="Odisha",
            latitude=19.8,
            longitude=85.8,
            capacity=200,
            occupancy=0,
            contact="1070",
            facilities="Medical, Water",
            status="ACTIVE"
        )
        self.requirement = ResourceRequirement.objects.create(
            camp=self.camp,
            resource_name="Blankets",
            required_quantity=100,
            received_quantity=20,
            unit="Pieces",
            status="URGENT"
        )

    def test_remaining_shortage_calculation(self):
        # 100 required - 20 received = 80 remaining
        self.assertEqual(self.requirement.remaining_quantity, 80)
        self.assertEqual(self.requirement.fulfillment_percentage, 20.0)

    def test_atomic_donation_verification(self):
        donation = Donation.objects.create(
            donor=self.citizen,
            camp=self.camp,
            resource_requirement=self.requirement,
            resource_name="Blankets",
            quantity=30,
            unit="Pieces",
            donor_name="Test Donor",
            status="PENDING"
        )

        # Before verification
        self.assertEqual(self.requirement.received_quantity, 20)

        # Execute verification
        success, msg = donation.verify(self.admin_user)
        self.assertTrue(success)

        # Requirement received quantity should increment from 20 to 50
        self.requirement.refresh_from_db()
        self.assertEqual(self.requirement.received_quantity, 50)
        self.assertEqual(self.requirement.remaining_quantity, 50)

        # Inventory on hand should have been created/credited with 30 Pieces
        inv = ResourceInventory.objects.get(camp=self.camp, resource_name="Blankets")
        self.assertEqual(inv.available_quantity, 30)

        # Second verification should be rejected to prevent duplicate credits
        success2, msg2 = donation.verify(self.admin_user)
        self.assertFalse(success2)
        self.assertIn("already verified", msg2)


class ViewSecurityAndHttpTestCase(TestCase):
    def setUp(self):
        self.client = Client()
        self.admin_user = User.objects.create_user(
            username="adminofficer",
            email="officer@aidbridge.org",
            password="pass",
            role="ADMIN"
        )
        self.citizen_user = User.objects.create_user(
            username="affectedperson",
            email="person@aidbridge.org",
            password="pass",
            role="CITIZEN"
        )

    def test_public_views_accessible(self):
        endpoints = [
            reverse('home'),
            reverse('about'),
            reverse('camps_public'),
            reverse('resources_public'),
            reverse('missing_persons_public'),
            reverse('notifications_public'),
            reverse('login'),
            reverse('register'),
        ]
        for url in endpoints:
            response = self.client.get(url)
            self.assertEqual(response.status_code, 200, f"Failed on endpoint {url}")

    def test_admin_dashboard_security_blocks_anonymous(self):
        response = self.client.get(reverse('admin_dashboard'))
        # Should redirect to login
        self.assertEqual(response.status_code, 302)
        self.assertIn(reverse('login'), response.url)

    def test_admin_dashboard_security_blocks_citizen(self):
        self.client.force_login(self.citizen_user)
        response = self.client.get(reverse('admin_dashboard'))
        # Citizen blocked from admin portal -> redirects to home with error message
        self.assertEqual(response.status_code, 302)
        self.assertIn(reverse('home'), response.url)

    def test_admin_dashboard_accessible_by_admin(self):
        self.client.force_login(self.admin_user)
        response = self.client.get(reverse('admin_dashboard'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Relief Command & Control Dashboard")

    def test_admin_camps_accessible_by_admin(self):
        self.client.force_login(self.admin_user)
        response = self.client.get(reverse('admin_camps_list'))
        self.assertEqual(response.status_code, 200)

    def test_admin_reports_accessible_by_admin(self):
        self.client.force_login(self.admin_user)
        response = self.client.get(reverse('admin_reports'))
        self.assertEqual(response.status_code, 200)
