"""
AidBridge Core URL Configuration
"""
from django.urls import path
from . import views, admin_views

urlpatterns = [
    # Public & Auth
    path('', views.home, name='home'),
    path('about/', views.about, name='about'),
    path('camps/', views.camps_public, name='camps_public'),
    path('resources/', views.resources_public, name='resources_public'),
    path('missing-persons/', views.missing_persons_public, name='missing_persons_public'),
    path('notifications/', views.notifications_public, name='notifications_public'),
    path('login/', views.login_view, name='login'),
    path('register/', views.register_view, name='register'),
    path('logout/', views.logout_view, name='logout'),

    # Admin Portal (Module 1 - Complete)
    path('admin-portal/', admin_views.admin_dashboard, name='admin_dashboard'),
    
    # Camp Management
    path('admin-portal/camps/', admin_views.admin_camps_list, name='admin_camps_list'),
    path('admin-portal/camps/create/', admin_views.admin_camp_create, name='admin_camp_create'),
    path('admin-portal/camps/<int:pk>/edit/', admin_views.admin_camp_edit, name='admin_camp_edit'),
    path('admin-portal/camps/<int:pk>/detail/', admin_views.admin_camp_detail, name='admin_camp_detail'),
    path('admin-portal/camps/<int:pk>/toggle-status/', admin_views.admin_camp_toggle_status, name='admin_camp_toggle_status'),
    path('admin-portal/camps/<int:pk>/delete/', admin_views.admin_camp_delete, name='admin_camp_delete'),

    # User Management
    path('admin-portal/users/', admin_views.admin_users_list, name='admin_users_list'),
    path('admin-portal/users/<int:pk>/detail/', admin_views.admin_user_detail, name='admin_user_detail'),
    path('admin-portal/users/<int:pk>/toggle-status/', admin_views.admin_user_toggle_status, name='admin_user_toggle_status'),
    path('admin-portal/users/<int:pk>/delete/', admin_views.admin_user_delete, name='admin_user_delete'),

    # Resident Management
    path('admin-portal/residents/', admin_views.admin_residents_list, name='admin_residents_list'),
    path('admin-portal/residents/create/', admin_views.admin_resident_create, name='admin_resident_create'),
    path('admin-portal/residents/<int:pk>/edit/', admin_views.admin_resident_edit, name='admin_resident_edit'),
    path('admin-portal/residents/<int:pk>/status/<str:new_status>/', admin_views.admin_resident_update_status, name='admin_resident_update_status'),
    path('admin-portal/residents/<int:pk>/delete/', admin_views.admin_resident_delete, name='admin_resident_delete'),

    # Resource & Inventory Management
    path('admin-portal/resources/', admin_views.admin_resources_list, name='admin_resources_list'),
    path('admin-portal/resources/create/', admin_views.admin_resource_create, name='admin_resource_create'),
    path('admin-portal/resources/<int:pk>/edit/', admin_views.admin_resource_edit, name='admin_resource_edit'),
    path('admin-portal/resources/<int:pk>/delete/', admin_views.admin_resource_delete, name='admin_resource_delete'),

    # Donation Management
    path('admin-portal/donations/', admin_views.admin_donations_list, name='admin_donations_list'),
    path('admin-portal/donations/<int:pk>/verify/', admin_views.admin_donation_verify, name='admin_donation_verify'),
    path('admin-portal/donations/<int:pk>/reject/', admin_views.admin_donation_reject, name='admin_donation_reject'),
    path('admin-portal/donations/<int:pk>/deliver/', admin_views.admin_donation_mark_delivered, name='admin_donation_mark_delivered'),

    # Missing Persons Management
    path('admin-portal/missing-persons/', admin_views.admin_missing_persons_list, name='admin_missing_persons_list'),
    path('admin-portal/missing-persons/<int:pk>/detail/', admin_views.admin_missing_person_detail, name='admin_missing_person_detail'),
    path('admin-portal/missing-persons/<int:pk>/status/<str:new_status>/', admin_views.admin_missing_person_update_status, name='admin_missing_person_update_status'),
    path('admin-portal/missing-persons/<int:pk>/delete/', admin_views.admin_missing_person_delete, name='admin_missing_person_delete'),

    # Notifications & Announcements
    path('admin-portal/notifications/', admin_views.admin_notifications_list, name='admin_notifications_list'),
    path('admin-portal/notifications/create/', admin_views.admin_notification_create, name='admin_notification_create'),
    path('admin-portal/notifications/<int:pk>/delete/', admin_views.admin_notification_delete, name='admin_notification_delete'),

    # Reports
    path('admin-portal/reports/', admin_views.admin_reports, name='admin_reports'),
    path('admin-portal/reports/print/', admin_views.admin_reports_printable, name='admin_reports_printable'),
]
