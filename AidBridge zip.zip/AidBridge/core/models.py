"""
AidBridge Core Models
Post-Disaster Relief Camp & Resource Management Portal
"""
from django.db import models, transaction
from django.contrib.auth.models import AbstractUser
from django.core.exceptions import ValidationError
from django.utils import timezone


class User(AbstractUser):
    """
    Custom User Model supporting Admins and Citizens.
    """
    ROLE_CHOICES = [
        ('ADMIN', 'Relief Administrator'),
        ('CITIZEN', 'Citizen / Affected Person'),
    ]

    STATUS_CHOICES = [
        ('ACTIVE', 'Active'),
        ('INACTIVE', 'Inactive'),
    ]

    email = models.EmailField(unique=True, verbose_name="Email Address")
    phone = models.CharField(max_length=20, blank=True, null=True, verbose_name="Phone Number")
    address = models.TextField(blank=True, null=True, verbose_name="Residential Address")
    role = models.CharField(max_length=10, choices=ROLE_CHOICES, default='CITIZEN', verbose_name="User Role")
    user_status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='ACTIVE', verbose_name="Account Status")
    created_at = models.DateTimeField(auto_now_add=True)

    def is_admin_user(self):
        return self.role == 'ADMIN' or self.is_superuser or self.is_staff

    def __str__(self):
        full = self.get_full_name()
        return f"{full} ({self.email})" if full else self.username


class ReliefCamp(models.Model):
    """
    Relief Camp model tracking location, capacity, and occupancy.
    """
    STATUS_CHOICES = [
        ('ACTIVE', 'Active'),
        ('FULL', 'Full'),
        ('INACTIVE', 'Inactive'),
    ]

    name = models.CharField(max_length=200, verbose_name="Camp Name")
    address = models.TextField(verbose_name="Camp Address")
    district = models.CharField(max_length=100, verbose_name="District")
    state = models.CharField(max_length=100, default="Kerala", verbose_name="State")
    latitude = models.DecimalField(max_digits=9, decimal_places=6, verbose_name="Latitude (GPS)")
    longitude = models.DecimalField(max_digits=9, decimal_places=6, verbose_name="Longitude (GPS)")
    capacity = models.PositiveIntegerField(verbose_name="Maximum Capacity (Persons)")
    occupancy = models.PositiveIntegerField(default=0, verbose_name="Current Occupancy")
    contact = models.CharField(max_length=50, verbose_name="Helpline Contact Number")
    facilities = models.TextField(
        help_text="Comma-separated or listed facilities, e.g. Drinking Water, Food Mess, Medical Bay, Sanitation, Electricity",
        verbose_name="Available Facilities"
    )
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='ACTIVE', verbose_name="Camp Status")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['district']),
            models.Index(fields=['status']),
        ]

    def clean(self):
        if self.occupancy > self.capacity:
            raise ValidationError(
                f"Current occupancy ({self.occupancy}) cannot exceed maximum capacity ({self.capacity})."
            )

    @property
    def remaining_capacity(self):
        """Remaining Capacity = Maximum Capacity - Current Occupancy"""
        return max(0, self.capacity - self.occupancy)

    @property
    def occupancy_percentage(self):
        if self.capacity <= 0:
            return 0
        return min(100, round((self.occupancy / self.capacity) * 100, 1))

    def update_occupancy_from_residents(self):
        """Recalculate occupancy based on approved residents and adjust camp status."""
        active_residents_count = self.residents.filter(status='APPROVED').count()
        self.occupancy = active_residents_count
        if self.occupancy >= self.capacity and self.capacity > 0:
            self.status = 'FULL'
        elif self.status == 'FULL' and self.occupancy < self.capacity:
            self.status = 'ACTIVE'
        self.save(update_fields=['occupancy', 'status'])

    def __str__(self):
        return f"{self.name} - {self.district} ({self.occupancy}/{self.capacity})"


class CampResident(models.Model):
    """
    Camp Resident (Disaster victim sheltered at relief camp).
    """
    STATUS_CHOICES = [
        ('PENDING', 'Pending Approval'),
        ('APPROVED', 'Approved / Sheltered'),
        ('DISCHARGED', 'Discharged / Returned Home'),
    ]

    GENDER_CHOICES = [
        ('Male', 'Male'),
        ('Female', 'Female'),
        ('Other', 'Other'),
    ]

    user = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, blank=True,
        related_name='resident_registrations',
        help_text="User account that submitted this registration, if registered online."
    )
    camp = models.ForeignKey(ReliefCamp, on_delete=models.CASCADE, related_name='residents')
    name = models.CharField(max_length=150, verbose_name="Resident Full Name")
    age = models.PositiveIntegerField(verbose_name="Age")
    gender = models.CharField(max_length=10, choices=GENDER_CHOICES, verbose_name="Gender")
    phone = models.CharField(max_length=20, blank=True, null=True, verbose_name="Contact Phone")
    emergency_contact = models.CharField(max_length=100, verbose_name="Emergency Contact (Name & Phone)")
    address = models.TextField(verbose_name="Original Residence Address", blank=True, null=True)
    medical_information = models.TextField(
        blank=True, null=True,
        verbose_name="Medical Conditions / Special Needs",
        help_text="E.g. Diabetic, Hypertension, Pregnant, Wheelchair, Pediatric"
    )
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='APPROVED', verbose_name="Resident Status")
    registered_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-registered_at']

    def clean(self):
        # Prevent approving resident if camp is full
        if self.status == 'APPROVED' and self.camp:
            current_active = self.camp.residents.filter(status='APPROVED').exclude(pk=self.pk).count()
            if current_active >= self.camp.capacity:
                raise ValidationError(f"Cannot assign resident: {self.camp.name} has reached maximum capacity ({self.camp.capacity}).")

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        if self.camp:
            self.camp.update_occupancy_from_residents()

    def delete(self, *args, **kwargs):
        camp = self.camp
        super().delete(*args, **kwargs)
        if camp:
            camp.update_occupancy_from_residents()

    def __str__(self):
        return f"{self.name} (Age {self.age}) - {self.camp.name}"


class ResourceRequirement(models.Model):
    """
    Relief supplies required by a specific camp.
    """
    STATUS_CHOICES = [
        ('URGENT', 'Urgent Shortage'),
        ('MODERATE', 'Moderate Need'),
        ('FULFILLED', 'Fulfilled'),
    ]

    camp = models.ForeignKey(ReliefCamp, on_delete=models.CASCADE, related_name='resource_requirements')
    resource_name = models.CharField(
        max_length=150, 
        verbose_name="Resource Item Name",
        help_text="E.g. Food Rice, Drinking Water, Blankets, Paracetamol, Infant Formula"
    )
    required_quantity = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Required Quantity")
    received_quantity = models.DecimalField(max_digits=10, decimal_places=2, default=0, verbose_name="Received Quantity")
    unit = models.CharField(max_length=50, verbose_name="Unit of Measurement", help_text="Kg, Liters, Packs, Units, Boxes")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='URGENT')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    @property
    def remaining_quantity(self):
        """Remaining requirement = Required - Received (prevent negative)."""
        diff = self.required_quantity - self.received_quantity
        return max(0, diff)

    @property
    def fulfillment_percentage(self):
        if self.required_quantity <= 0:
            return 100.0
        pct = (self.received_quantity / self.required_quantity) * 100
        return min(100.0, round(float(pct), 1))

    def update_fulfillment_status(self):
        if self.received_quantity >= self.required_quantity:
            self.status = 'FULFILLED'
        elif self.fulfillment_percentage >= 50:
            self.status = 'MODERATE'
        else:
            self.status = 'URGENT'

    def __str__(self):
        return f"{self.resource_name} ({self.camp.name}): Req={self.required_quantity} {self.unit}, Recv={self.received_quantity} {self.unit}"


class ResourceInventory(models.Model):
    """
    Camp-level available stock on hand.
    """
    camp = models.ForeignKey(ReliefCamp, on_delete=models.CASCADE, related_name='inventory_items')
    resource_name = models.CharField(max_length=150, verbose_name="Resource Name")
    available_quantity = models.DecimalField(max_digits=10, decimal_places=2, default=0, verbose_name="Available Stock")
    unit = models.CharField(max_length=50, verbose_name="Unit")
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ('camp', 'resource_name')
        verbose_name_plural = 'Resource Inventories'

    def __str__(self):
        return f"{self.camp.name} - {self.resource_name}: {self.available_quantity} {self.unit}"


class Donation(models.Model):
    """
    Donation made towards camp supplies.
    Supports atomic verification and inventory credit.
    """
    STATUS_CHOICES = [
        ('PENDING', 'Pending Verification'),
        ('VERIFIED', 'Verified & Credited'),
        ('REJECTED', 'Rejected'),
        ('DELIVERED', 'Delivered to Camp'),
    ]

    donor = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='donations')
    camp = models.ForeignKey(ReliefCamp, on_delete=models.CASCADE, related_name='donations')
    resource_requirement = models.ForeignKey(
        ResourceRequirement, on_delete=models.SET_NULL, null=True, blank=True,
        related_name='donations'
    )
    resource_name = models.CharField(max_length=150, verbose_name="Resource Donated")
    quantity = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Donated Quantity")
    unit = models.CharField(max_length=50, default="units", verbose_name="Unit")
    donor_name = models.CharField(max_length=150, verbose_name="Donor Full Name", blank=True, null=True)
    donor_phone = models.CharField(max_length=20, blank=True, null=True, verbose_name="Donor Contact")
    message = models.TextField(blank=True, null=True, verbose_name="Message / Delivery Details")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='PENDING', verbose_name="Donation Status")
    created_at = models.DateTimeField(auto_now_add=True)
    verified_at = models.DateTimeField(null=True, blank=True)
    verified_by = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, blank=True, 
        related_name='verified_donations'
    )

    class Meta:
        ordering = ['-created_at']

    def verify(self, admin_user):
        """
        Verify donation and atomically update:
        1. ResourceRequirement received_quantity & status
        2. ResourceInventory available_quantity
        Prevents double-verification.
        """
        if self.status == 'VERIFIED':
            return False, "This donation is already verified."

        with transaction.atomic():
            self.status = 'VERIFIED'
            self.verified_at = timezone.now()
            self.verified_by = admin_user
            self.save(update_fields=['status', 'verified_at', 'verified_by'])

            # 1. Update ResourceRequirement if linked or matched by name
            req = self.resource_requirement
            if not req and self.camp:
                req = ResourceRequirement.objects.filter(
                    camp=self.camp, 
                    resource_name__iexact=self.resource_name
                ).first()

            if req:
                req.received_quantity += self.quantity
                req.update_fulfillment_status()
                req.save()

            # 2. Update ResourceInventory
            inventory, _ = ResourceInventory.objects.get_or_create(
                camp=self.camp,
                resource_name=self.resource_name,
                defaults={'unit': self.unit, 'available_quantity': 0}
            )
            inventory.available_quantity += self.quantity
            inventory.save()

            # 3. Create Notification for Donor if registered
            if self.donor:
                Notification.objects.create(
                    user=self.donor,
                    title="Donation Verified Successfully",
                    message=f"Thank you! Your donation of {self.quantity} {self.unit} {self.resource_name} for {self.camp.name} has been verified by the Relief Administration.",
                    notification_type='DONATION'
                )

        return True, "Donation verified and supplies credited successfully."

    def __str__(self):
        return f"Donation #{self.id} - {self.quantity} {self.unit} {self.resource_name} by {self.donor_name or (self.donor.get_full_name() if self.donor else 'Anonymous')}"


class MissingPerson(models.Model):
    """
    Missing person record reported after a disaster.
    """
    STATUS_CHOICES = [
        ('MISSING', 'Missing'),
        ('LOCATED', 'Located / Found'),
        ('VERIFIED', 'Verified Missing'),
    ]

    GENDER_CHOICES = [
        ('Male', 'Male'),
        ('Female', 'Female'),
        ('Other', 'Other'),
    ]

    reporter = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='reported_missing')
    reporter_name = models.CharField(max_length=150, verbose_name="Reporter Name")
    reporter_phone = models.CharField(max_length=20, verbose_name="Reporter Contact Phone")
    name = models.CharField(max_length=150, verbose_name="Missing Person Name")
    age = models.PositiveIntegerField(verbose_name="Age")
    gender = models.CharField(max_length=10, choices=GENDER_CHOICES, verbose_name="Gender")
    last_known_location = models.CharField(max_length=255, verbose_name="Last Known Location")
    description = models.TextField(
        verbose_name="Physical Description & Identifiers",
        help_text="Height, clothing when last seen, birthmarks, languages spoken, etc."
    )
    photo = models.ImageField(upload_to='missing_persons/', blank=True, null=True, verbose_name="Photograph")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='MISSING', verbose_name="Status")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.name} (Age {self.age}) - {self.status}"


class Notification(models.Model):
    """
    System notifications and announcements.
    If user is null, it represents a global broadcast announcement.
    """
    TYPE_CHOICES = [
        ('ANNOUNCEMENT', 'Camp Announcement'),
        ('DONATION', 'Donation Update'),
        ('CAMP_UPDATE', 'Camp Status Notice'),
        ('RESIDENT_STATUS', 'Resident Status Update'),
        ('GENERAL', 'Important Notice'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True, related_name='notifications')
    title = models.CharField(max_length=200, verbose_name="Notification Title")
    message = models.TextField(verbose_name="Notification Content")
    notification_type = models.CharField(max_length=30, choices=TYPE_CHOICES, default='GENERAL')
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        recipient = self.user.username if self.user else "GLOBAL BROADCAST"
        return f"[{self.notification_type}] {self.title} -> {recipient}"
