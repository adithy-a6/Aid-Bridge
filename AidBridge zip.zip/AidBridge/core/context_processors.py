"""
Context processors for AidBridge.
Provides global notification badges and portal metadata across all templates.
"""
from .models import Notification, Donation

def global_context(request):
    context = {
        'SITE_NAME': 'AidBridge',
        'PORTAL_SUBTITLE': 'Post-Disaster Relief Camp & Resource Management Portal',
        'global_unread_notifications': 0,
        'admin_pending_donations_count': 0,
    }

    if request.user.is_authenticated:
        # User unread notifications + global broadcasts
        user_notifications = Notification.objects.filter(user=request.user, is_read=False).count()
        global_broadcasts = Notification.objects.filter(user__isnull=True).count()
        context['global_unread_notifications'] = user_notifications + global_broadcasts

        if request.user.is_admin_user():
            context['admin_pending_donations_count'] = Donation.objects.filter(status='PENDING').count()

    # Active broadcast announcements for ticker
    context['latest_broadcasts'] = Notification.objects.filter(
        user__isnull=True, 
        notification_type='ANNOUNCEMENT'
    ).order_by('-created_at')[:3]

    return context
