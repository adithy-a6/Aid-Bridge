"""
Django Admin Site Configuration for AidBridge
Provides standard Django ORM administrative interface with rich search, filters, and list displays.
"""
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from .models import (
    User, ReliefCamp, CampResident, ResourceRequirement, 
    ResourceInventory, Donation, MissingPerson, Notification
)


@admin.register(User)
class CustomUserAdmin(BaseUserAdmin):
    list_display = ('username', 'email', 'first_name', 'last_name', 'role', 'user_status', 'is_staff')
    list_filter = ('role', 'user_status', 'is_staff', 'is_superuser')
    search_fields = ('username', 'email', 'first_name', 'last_name', 'phone')
    ordering = ('-date_joined',)
    fieldsets = BaseUserAdmin.fieldsets + (
        ('AidBridge Role & Info', {'fields': ('role', 'user_status', 'phone', 'address')}),
    )


@admin.register(ReliefCamp)
class ReliefCampAdmin(admin.ModelAdmin):
    list_display = ('name', 'district', 'state', 'capacity', 'occupancy', 'remaining_capacity_display', 'status', 'created_at')
    list_filter = ('district', 'status', 'state')
    search_fields = ('name', 'district', 'address', 'facilities')
    ordering = ('-created_at',)

    @admin.display(description="Remaining Capacity")
    def remaining_capacity_display(self, obj):
        return obj.remaining_capacity


@admin.register(CampResident)
class CampResidentAdmin(admin.ModelAdmin):
    list_display = ('name', 'age', 'gender', 'camp', 'phone', 'emergency_contact', 'status', 'registered_at')
    list_filter = ('status', 'gender', 'camp')
    search_fields = ('name', 'phone', 'emergency_contact', 'medical_information')
    ordering = ('-registered_at',)


@admin.register(ResourceRequirement)
class ResourceRequirementAdmin(admin.ModelAdmin):
    list_display = ('resource_name', 'camp', 'required_quantity', 'received_quantity', 'remaining_quantity_display', 'unit', 'status', 'created_at')
    list_filter = ('status', 'camp')
    search_fields = ('resource_name', 'camp__name')
    ordering = ('-created_at',)

    @admin.display(description="Shortage / Remaining")
    def remaining_quantity_display(self, obj):
        return obj.remaining_quantity


@admin.register(ResourceInventory)
class ResourceInventoryAdmin(admin.ModelAdmin):
    list_display = ('resource_name', 'camp', 'available_quantity', 'unit', 'updated_at')
    list_filter = ('camp',)
    search_fields = ('resource_name', 'camp__name')
    ordering = ('camp', 'resource_name')


@admin.register(Donation)
class DonationAdmin(admin.ModelAdmin):
    list_display = ('id', 'resource_name', 'quantity', 'unit', 'camp', 'donor_name', 'status', 'created_at', 'verified_at')
    list_filter = ('status', 'camp')
    search_fields = ('resource_name', 'donor_name', 'camp__name', 'message')
    ordering = ('-created_at',)
    actions = ['verify_selected_donations']

    @admin.action(description="Verify and Credit Selected Donations")
    def verify_selected_donations(self, request, queryset):
        count = 0
        for donation in queryset.filter(status='PENDING'):
            success, _ = donation.verify(request.user)
            if success:
                count += 1
        self.message_user(request, f"{count} donation(s) verified and credited to camp inventory.")


@admin.register(MissingPerson)
class MissingPersonAdmin(admin.ModelAdmin):
    list_display = ('name', 'age', 'gender', 'last_known_location', 'status', 'reporter_name', 'reporter_phone', 'created_at')
    list_filter = ('status', 'gender')
    search_fields = ('name', 'last_known_location', 'description', 'reporter_name')
    ordering = ('-created_at',)


@admin.register(Notification)
class NotificationAdmin(admin.ModelAdmin):
    list_display = ('title', 'notification_type', 'user', 'is_read', 'created_at')
    list_filter = ('notification_type', 'is_read')
    search_fields = ('title', 'message')
    ordering = ('-created_at',)
