/**
 * AidBridge: Post-Disaster Relief Camp & Resource Management Portal
 * Client-Side Utilities: Geolocation, Haversine Calculation, Demo Logins
 */

document.addEventListener('DOMContentLoaded', function () {
  // Initialize Bootstrap Tooltips if available
  const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
  tooltipTriggerList.map(function (tooltipTriggerEl) {
    return new bootstrap.Tooltip(tooltipTriggerEl);
  });

  // Auto-dismiss alert messages after 6 seconds
  setTimeout(function () {
    const alerts = document.querySelectorAll('.alert-dismissible');
    alerts.forEach(function (alert) {
      const bsAlert = new bootstrap.Alert(alert);
      bsAlert.close();
    });
  }, 6000);
});

/**
 * Request user's current GPS location and reload camps page with coordinates
 */
function locateUserAndSortCamps() {
  const btn = document.getElementById('locate-btn');
  const statusSpan = document.getElementById('location-status');

  if (!navigator.geolocation) {
    alert("Geolocation is not supported by your browser.");
    return;
  }

  if (btn) {
    btn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status"></span> Detecting GPS...';
    btn.disabled = true;
  }
  if (statusSpan) {
    statusSpan.textContent = "Acquiring your GPS coordinates...";
  }

  navigator.geolocation.getCurrentPosition(
    function (position) {
      const lat = position.coords.latitude.toFixed(6);
      const lng = position.coords.longitude.toFixed(6);

      const url = new URL(window.location.href);
      url.searchParams.set('lat', lat);
      url.searchParams.set('lng', lng);
      window.location.href = url.toString();
    },
    function (error) {
      let msg = "Unable to retrieve your location.";
      if (error.code === error.PERMISSION_DENIED) {
        msg = "Location access was denied. Please allow location permissions in your browser.";
      }
      alert(msg);
      if (btn) {
        btn.innerHTML = '<i class="bi bi-geo-alt-fill"></i> Use My GPS Location';
        btn.disabled = false;
      }
      if (statusSpan) {
        statusSpan.textContent = msg;
      }
    },
    { timeout: 10000, enableHighAccuracy: true }
  );
}

/**
 * Quick-fill demo credentials for MCA examiners and testing
 */
function fillDemoCredentials(role) {
  const identifierInput = document.getElementById('id_login_identifier') || document.querySelector('input[name="login_identifier"]');
  const passwordInput = document.getElementById('id_password') || document.querySelector('input[name="password"]');

  if (!identifierInput || !passwordInput) return;

  if (role === 'admin') {
    identifierInput.value = 'admin@aidbridge.org';
    passwordInput.value = 'admin123';
  } else if (role === 'citizen') {
    identifierInput.value = 'citizen@aidbridge.org';
    passwordInput.value = 'user123';
  }
}
