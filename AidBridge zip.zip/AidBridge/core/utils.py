"""
AidBridge Utility Functions
Distance calculation, permission decorators, and analytical aggregations.
"""
import math
from functools import wraps
from django.shortcuts import redirect
from django.contrib import messages
from django.db.models import Sum, Count, Q
from django.core.exceptions import PermissionDenied


def haversine_distance(lat1, lon1, lat2, lon2):
    """
    Calculate the great circle distance between two points 
    on the earth (specified in decimal degrees).
    Returns distance in kilometers (km), rounded to 2 decimal places.
    """
    try:
        lat1, lon1, lat2, lon2 = map(float, [lat1, lon1, lat2, lon2])
    except (ValueError, TypeError):
        return None

    # Radius of earth in kilometers
    r = 6371.0

    # Convert decimal degrees to radians
    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)
    delta_phi = math.radians(lat2 - lat1)
    delta_lambda = math.radians(lon2 - lon1)

    # Haversine formula
    a = (math.sin(delta_phi / 2.0) ** 2 +
         math.cos(phi1) * math.cos(phi2) * (math.sin(delta_lambda / 2.0) ** 2))
    
    c = 2 * math.asin(math.sqrt(min(1.0, a)))
    d = r * c

    return round(d, 2)


def admin_required(view_func):
    """
    Decorator to ensure user is logged in and has the ADMIN role or superuser/staff status.
    """
    @wraps(view_func)
    def _wrapped_view(request, *args, **kwargs):
        if not request.user.is_authenticated:
            messages.warning(request, "Please log in with administrator credentials to access the Admin Portal.")
            return redirect('login')
        if not request.user.is_admin_user():
            messages.error(request, "Access Denied: You do not have permission to view the Admin Portal.")
            return redirect('home')
        return view_func(request, *args, **kwargs)
    return _wrapped_view


def get_admin_dashboard_metrics():
    """
    Calculate real database metrics for the Admin Dashboard.
    No hard-coded values; every metric reflects real database rows.
    """
    from .models import (
        User, ReliefCamp, CampResident, ResourceRequirement, 
        ResourceInventory, Donation, MissingPerson
    )

    total_users = User.objects.count()
    total_camps = ReliefCamp.objects.count()
    active_camps = ReliefCamp.objects.filter(status='ACTIVE').count()
    full_camps = ReliefCamp.objects.filter(status='FULL').count()

    total_residents = CampResident.objects.filter(status='APPROVED').count()
    pending_residents = CampResident.objects.filter(status='PENDING').count()

    total_donations = Donation.objects.count()
    pending_donations = Donation.objects.filter(status='PENDING').count()
    verified_donations = Donation.objects.filter(status='VERIFIED').count()

    # Sum of available resources across all inventories
    available_resources_sum = ResourceInventory.objects.aggregate(
        total=Sum('available_quantity')
    )['total'] or 0

    # Resource requirements
    total_requirements_count = ResourceRequirement.objects.count()
    urgent_requirements_count = ResourceRequirement.objects.filter(status='URGENT').count()
    
    # Missing persons
    total_missing = MissingPerson.objects.count()
    active_missing = MissingPerson.objects.filter(status='MISSING').count()
    located_missing = MissingPerson.objects.filter(status='LOCATED').count()

    # Camp capacity stats
    total_capacity = ReliefCamp.objects.aggregate(total=Sum('capacity'))['total'] or 0
    total_occupancy = ReliefCamp.objects.aggregate(total=Sum('occupancy'))['total'] or 0
    remaining_capacity = max(0, total_capacity - total_occupancy)

    # Chart 1: Camp Occupancy Comparison (up to 8 camps)
    camps_query = ReliefCamp.objects.all()[:8]
    chart_camp_names = [c.name for c in camps_query]
    chart_camp_occupancy = [c.occupancy for c in camps_query]
    chart_camp_capacity = [c.capacity for c in camps_query]
    chart_camp_remaining = [c.remaining_capacity for c in camps_query]

    # Chart 2: Donations Status Distribution
    chart_donation_labels = ['Verified', 'Pending', 'Delivered', 'Rejected']
    chart_donation_counts = [
        Donation.objects.filter(status='VERIFIED').count(),
        Donation.objects.filter(status='PENDING').count(),
        Donation.objects.filter(status='DELIVERED').count(),
        Donation.objects.filter(status='REJECTED').count(),
    ]

    # Chart 3: Missing Persons Status
    chart_missing_labels = ['Missing', 'Located', 'Verified Missing']
    chart_missing_counts = [
        MissingPerson.objects.filter(status='MISSING').count(),
        MissingPerson.objects.filter(status='LOCATED').count(),
        MissingPerson.objects.filter(status='VERIFIED').count(),
    ]

    return {
        'total_users': total_users,
        'total_camps': total_camps,
        'active_camps': active_camps,
        'full_camps': full_camps,
        'total_residents': total_residents,
        'pending_residents': pending_residents,
        'total_donations': total_donations,
        'pending_donations': pending_donations,
        'verified_donations': verified_donations,
        'available_resources_sum': round(float(available_resources_sum), 1),
        'total_requirements_count': total_requirements_count,
        'urgent_requirements_count': urgent_requirements_count,
        'total_missing': total_missing,
        'active_missing': active_missing,
        'located_missing': located_missing,
        'total_capacity': total_capacity,
        'total_occupancy': total_occupancy,
        'remaining_capacity': remaining_capacity,
        'chart_camp_names': chart_camp_names,
        'chart_camp_occupancy': chart_camp_occupancy,
        'chart_camp_capacity': chart_camp_capacity,
        'chart_camp_remaining': chart_camp_remaining,
        'chart_donation_labels': chart_donation_labels,
        'chart_donation_counts': chart_donation_counts,
        'chart_missing_labels': chart_missing_labels,
        'chart_missing_counts': chart_missing_counts,
    }
