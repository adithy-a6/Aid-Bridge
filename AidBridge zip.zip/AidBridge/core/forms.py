"""
AidBridge Forms
Validation and widget styling for Bootstrap 5.
"""
from django import forms
from django.contrib.auth import authenticate
from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError

from .models import (
    User, ReliefCamp, CampResident, ResourceRequirement, 
    ResourceInventory, Donation, MissingPerson, Notification
)


class UserLoginForm(forms.Form):
    """
    Login form allowing email or username authentication.
    """
    login_identifier = forms.CharField(
        label="Email or Username",
        widget=forms.TextInput(attrs={
            'class': 'form-control form-control-lg',
            'placeholder': 'Enter your registered email or username',
            'autofocus': True,
        })
    )
    password = forms.CharField(
        label="Password",
        widget=forms.PasswordInput(attrs={
            'class': 'form-control form-control-lg',
            'placeholder': 'Enter your password'
        })
    )

    def clean(self):
        cleaned_data = super().clean()
        identifier = cleaned_data.get('login_identifier')
        password = cleaned_data.get('password')

        if identifier and password:
            # Check if identifier is email
            user_by_email = User.objects.filter(email__iexact=identifier).first()
            username = user_by_email.username if user_by_email else identifier

            user = authenticate(username=username, password=password)
            if not user:
                raise ValidationError("Invalid login credentials. Please check your username/email and password.")
            if user.user_status == 'INACTIVE':
                raise ValidationError("Your account has been deactivated by the administration. Please contact helpline.")
            
            cleaned_data['user'] = user

        return cleaned_data


class UserRegistrationForm(forms.ModelForm):
    """
    Citizen registration form.
    """
    full_name = forms.CharField(
        max_length=150,
        required=True,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g. Rahul Sharma'})
    )
    email = forms.EmailField(
        required=True,
        widget=forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'name@example.com'})
    )
    phone = forms.CharField(
        max_length=20,
        required=True,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': '+91 98765 43210'})
    )
    address = forms.CharField(
        required=True,
        widget=forms.Textarea(attrs={'class': 'form-control', 'rows': 2, 'placeholder': 'Permanent address / District'})
    )
    password = forms.CharField(
        widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'At least 6 characters'})
    )
    confirm_password = forms.CharField(
        widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Confirm your password'})
    )

    class Meta:
        model = User
        fields = ['full_name', 'email', 'phone', 'address']

    def clean_email(self):
        email = self.cleaned_data.get('email').lower()
        if User.objects.filter(email=email).exists():
            raise ValidationError("An account with this email address already exists.")
        return email

    def clean(self):
        cleaned_data = super().clean()
        pwd = cleaned_data.get('password')
        pwd_confirm = cleaned_data.get('confirm_password')

        if pwd and pwd_confirm:
            if pwd != pwd_confirm:
                self.add_error('confirm_password', "Passwords do not match.")
            else:
                validate_password(pwd)
        return cleaned_data

    def save(self, commit=True):
        user = super().save(commit=False)
        full_name = self.cleaned_data.get('full_name', '').strip()
        parts = full_name.split(' ', 1)
        user.first_name = parts[0]
        user.last_name = parts[1] if len(parts) > 1 else ''
        user.username = self.cleaned_data.get('email')
        user.role = 'CITIZEN'
        user.user_status = 'ACTIVE'
        user.set_password(self.cleaned_data.get('password'))
        if commit:
            user.save()
        return user


class ReliefCampForm(forms.ModelForm):
    """
    Form for creating and editing relief camps.
    """
    class Meta:
        model = ReliefCamp
        fields = [
            'name', 'district', 'state', 'address', 'contact',
            'capacity', 'occupancy', 'latitude', 'longitude',
            'facilities', 'status'
        ]
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g. Green Valley Relief Camp'}),
            'district': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g. Wayanad'}),
            'state': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g. Kerala'}),
            'address': forms.Textarea(attrs={'class': 'form-control', 'rows': 2, 'placeholder': 'Street, Village, Landmark'}),
            'contact': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g. +91 98470 12345'}),
            'capacity': forms.NumberInput(attrs={'class': 'form-control', 'min': 1}),
            'occupancy': forms.NumberInput(attrs={'class': 'form-control', 'min': 0}),
            'latitude': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.000001', 'placeholder': 'e.g. 11.685400'}),
            'longitude': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.000001', 'placeholder': 'e.g. 76.132000'}),
            'facilities': forms.Textarea(attrs={'class': 'form-control', 'rows': 3, 'placeholder': 'Drinking Water, Medical Bay, Sanitation, Mess Kitchen, Electricity'}),
            'status': forms.Select(attrs={'class': 'form-select'}),
        }

    def clean(self):
        cleaned_data = super().clean()
        capacity = cleaned_data.get('capacity')
        occupancy = cleaned_data.get('occupancy')

        if capacity is not None and occupancy is not None:
            if occupancy > capacity:
                self.add_error('occupancy', f"Current occupancy ({occupancy}) cannot exceed maximum capacity ({capacity}).")
            if occupancy >= capacity and cleaned_data.get('status') == 'ACTIVE':
                cleaned_data['status'] = 'FULL'
        return cleaned_data


class CampResidentForm(forms.ModelForm):
    """
    Form for registering or updating a camp resident.
    """
    class Meta:
        model = CampResident
        fields = [
            'camp', 'name', 'age', 'gender', 'phone', 
            'emergency_contact', 'address', 'medical_information', 'status'
        ]
        widgets = {
            'camp': forms.Select(attrs={'class': 'form-select'}),
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Full Name'}),
            'age': forms.NumberInput(attrs={'class': 'form-control', 'min': 0, 'max': 120}),
            'gender': forms.Select(attrs={'class': 'form-select'}),
            'phone': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Phone Number'}),
            'emergency_contact': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Contact Person & Phone'}),
            'address': forms.Textarea(attrs={'class': 'form-control', 'rows': 2, 'placeholder': 'Pre-disaster address'}),
            'medical_information': forms.Textarea(attrs={'class': 'form-control', 'rows': 2, 'placeholder': 'E.g. Diabetic, Asthma, Pregnant, Special diet'}),
            'status': forms.Select(attrs={'class': 'form-select'}),
        }

    def clean(self):
        cleaned_data = super().clean()
        camp = cleaned_data.get('camp')
        status = cleaned_data.get('status')

        if camp and status == 'APPROVED':
            current_active = camp.residents.filter(status='APPROVED')
            if self.instance.pk:
                current_active = current_active.exclude(pk=self.instance.pk)
            if current_active.count() >= camp.capacity:
                raise ValidationError(
                    f"Selected camp '{camp.name}' is already at maximum capacity ({camp.capacity}). Please choose another camp or expand capacity."
                )
        return cleaned_data


class ResourceRequirementForm(forms.ModelForm):
    """
    Form to post or update a resource requirement for a relief camp.
    """
    class Meta:
        model = ResourceRequirement
        fields = ['camp', 'resource_name', 'required_quantity', 'received_quantity', 'unit', 'status']
        widgets = {
            'camp': forms.Select(attrs={'class': 'form-select'}),
            'resource_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g. Drinking Water, Food Rice, Blankets'}),
            'required_quantity': forms.NumberInput(attrs={'class': 'form-control', 'min': 1, 'step': '0.1'}),
            'received_quantity': forms.NumberInput(attrs={'class': 'form-control', 'min': 0, 'step': '0.1'}),
            'unit': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g. Liters, Kg, Packs, Blankets'}),
            'status': forms.Select(attrs={'class': 'form-select'}),
        }

    def clean(self):
        cleaned_data = super().clean()
        required = cleaned_data.get('required_quantity')
        received = cleaned_data.get('received_quantity')

        if required is not None and received is not None:
            if received > required:
                # Flag or adjust
                pass
            if received >= required:
                cleaned_data['status'] = 'FULFILLED'
        return cleaned_data


class ResourceInventoryForm(forms.ModelForm):
    """
    Form for tracking available inventory in stock.
    """
    class Meta:
        model = ResourceInventory
        fields = ['camp', 'resource_name', 'available_quantity', 'unit']
        widgets = {
            'camp': forms.Select(attrs={'class': 'form-select'}),
            'resource_name': forms.TextInput(attrs={'class': 'form-control'}),
            'available_quantity': forms.NumberInput(attrs={'class': 'form-control', 'min': 0, 'step': '0.1'}),
            'unit': forms.TextInput(attrs={'class': 'form-control'}),
        }


class DonationForm(forms.ModelForm):
    """
    Form for recording an item donation.
    """
    class Meta:
        model = Donation
        fields = ['camp', 'resource_requirement', 'resource_name', 'quantity', 'unit', 'donor_name', 'donor_phone', 'message']
        widgets = {
            'camp': forms.Select(attrs={'class': 'form-select', 'id': 'id_camp_select'}),
            'resource_requirement': forms.Select(attrs={'class': 'form-select', 'id': 'id_resource_select'}),
            'resource_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Item Name (e.g. Blankets, Rice)'}),
            'quantity': forms.NumberInput(attrs={'class': 'form-control', 'min': 1, 'step': '0.1'}),
            'unit': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g. pieces, kg, boxes'}),
            'donor_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Your Name'}),
            'donor_phone': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Your Contact Number'}),
            'message': forms.Textarea(attrs={'class': 'form-control', 'rows': 2, 'placeholder': 'Delivery notes or remarks'}),
        }


class MissingPersonForm(forms.ModelForm):
    """
    Form to report a missing person after a disaster.
    """
    class Meta:
        model = MissingPerson
        fields = [
            'name', 'age', 'gender', 'last_known_location', 
            'description', 'photo', 'reporter_name', 'reporter_phone', 'status'
        ]
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Full Name of Missing Person'}),
            'age': forms.NumberInput(attrs={'class': 'form-control', 'min': 0, 'max': 120}),
            'gender': forms.Select(attrs={'class': 'form-select'}),
            'last_known_location': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Village, Street, Building, District'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'rows': 3, 'placeholder': 'Height, clothes worn, physical marks, spoken languages...'}),
            'photo': forms.FileInput(attrs={'class': 'form-control'}),
            'reporter_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Your Full Name'}),
            'reporter_phone': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Your Phone Number'}),
            'status': forms.Select(attrs={'class': 'form-select'}),
        }


class NotificationForm(forms.ModelForm):
    """
    Form for sending global broadcasts or user notifications.
    """
    class Meta:
        model = Notification
        fields = ['user', 'title', 'message', 'notification_type']
        widgets = {
            'user': forms.Select(attrs={'class': 'form-select'}),
            'title': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Notification Headline'}),
            'message': forms.Textarea(attrs={'class': 'form-control', 'rows': 4, 'placeholder': 'Write announcement or bulletin message here...'}),
            'notification_type': forms.Select(attrs={'class': 'form-select'}),
        }
        labels = {
            'user': 'Specific Recipient (Leave empty for Global Broadcast)'
        }
