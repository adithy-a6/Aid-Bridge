"""
AidBridge Admin Module Views
Complete administrative control over camps, residents, resources,
donations, missing persons, notifications, and reports.
"""
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.db.models import Sum, Count, Q
from django.http import JsonResponse
from django.utils import timezone

from .models import (
    User, ReliefCamp, CampResident, ResourceRequirement, 
    ResourceInventory, Donation, MissingPerson, Notification
)
from .forms import (
    ReliefCampForm, CampResidentForm, ResourceRequirementForm,
    ResourceInventoryForm, MissingPersonForm, NotificationForm
)
from .utils import admin_required, get_admin_dashboard_metrics


@admin_required
def admin_dashboard(request):
    """
    Main Administrative Dashboard: Real DB metrics, Chart.js visuals, pending queues.
    """
    metrics = get_admin_dashboard_metrics()
    
    # Recent pending items requiring attention
    pending_donations_list = Donation.objects.filter(status='PENDING').select_related('camp')[:5]
    recent_residents = CampResident.objects.select_related('camp').order_by('-registered_at')[:5]
    recent_missing = MissingPerson.objects.filter(status='MISSING').order_by('-created_at')[:5]

    context = {
        'metrics': metrics,
        'pending_donations_list': pending_donations_list,
        'recent_residents': recent_residents,
        'recent_missing': recent_missing,
        'page_title': 'Admin Control Center',
    }
    return render(request, 'admin/dashboard.html', context)


# ==========================================
# RELIEF CAMP MANAGEMENT
# ==========================================

@admin_required
def admin_camps_list(request):
    query = request.GET.get('q', '').strip()
    district = request.GET.get('district', '').strip()
    status = request.GET.get('status', '').strip()

    camps = ReliefCamp.objects.all()
    if query:
        camps = camps.filter(
            Q(name__icontains=query) | Q(address__icontains=query) | Q(facilities__icontains=query)
        )
    if district:
        camps = camps.filter(district__iexact=district)
    if status:
        camps = camps.filter(status=status)

    districts = ReliefCamp.objects.values_list('district', flat=True).distinct()

    context = {
        'camps': camps,
        'districts': districts,
        'selected_district': district,
        'selected_status': status,
        'query': query,
        'page_title': 'Relief Camp Management',
    }
    return render(request, 'admin/camps/list.html', context)


@admin_required
def admin_camp_create(request):
    form = ReliefCampForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        camp = form.save()
        messages.success(request, f"Relief Camp '{camp.name}' created successfully.")
        return redirect('admin_camps_list')

    return render(request, 'admin/camps/form.html', {
        'form': form,
        'action_title': 'Establish New Relief Camp',
        'page_title': 'Add Relief Camp',
    })


@admin_required
def admin_camp_edit(request, pk):
    camp = get_object_or_404(ReliefCamp, pk=pk)
    form = ReliefCampForm(request.POST or None, instance=camp)
    if request.method == 'POST' and form.is_valid():
        camp = form.save()
        messages.success(request, f"Relief Camp '{camp.name}' updated successfully.")
        return redirect('admin_camps_list')

    return render(request, 'admin/camps/form.html', {
        'form': form,
        'camp': camp,
        'action_title': f'Edit Relief Camp: {camp.name}',
        'page_title': 'Edit Relief Camp',
    })


@admin_required
def admin_camp_detail(request, pk):
    camp = get_object_or_404(ReliefCamp, pk=pk)
    residents = camp.residents.all()[:20]
    requirements = camp.resource_requirements.all()
    inventory = camp.inventory_items.all()
    donations = camp.donations.order_by('-created_at')[:10]

    context = {
        'camp': camp,
        'residents': residents,
        'requirements': requirements,
        'inventory': inventory,
        'donations': donations,
        'page_title': f'Camp Details - {camp.name}',
    }
    return render(request, 'admin/camps/detail.html', context)


@admin_required
def admin_camp_toggle_status(request, pk):
    camp = get_object_or_404(ReliefCamp, pk=pk)
    if camp.status == 'ACTIVE':
        camp.status = 'INACTIVE'
    elif camp.status == 'INACTIVE':
        camp.status = 'ACTIVE'
    camp.save(update_fields=['status'])
    messages.info(request, f"Camp '{camp.name}' status set to {camp.get_status_display()}.")
    return redirect('admin_camps_list')


@admin_required
def admin_camp_delete(request, pk):
    camp = get_object_or_404(ReliefCamp, pk=pk)
    active_count = camp.residents.filter(status='APPROVED').count()
    if active_count > 0:
        messages.error(
            request, 
            f"Cannot delete '{camp.name}'! There are {active_count} active residents currently sheltered here. Please reassign them first."
        )
        return redirect('admin_camps_list')

    camp_name = camp.name
    camp.delete()
    messages.success(request, f"Relief Camp '{camp_name}' has been safely deleted.")
    return redirect('admin_camps_list')


# ==========================================
# USER MANAGEMENT
# ==========================================

@admin_required
def admin_users_list(request):
    query = request.GET.get('q', '').strip()
    role = request.GET.get('role', '').strip()
    status = request.GET.get('status', '').strip()

    users = User.objects.all().order_by('-date_joined')
    if query:
        users = users.filter(
            Q(username__icontains=query) | Q(email__icontains=query) | 
            Q(first_name__icontains=query) | Q(last_name__icontains=query) |
            Q(phone__icontains=query)
        )
    if role:
        users = users.filter(role=role)
    if status:
        users = users.filter(user_status=status)

    context = {
        'users': users,
        'query': query,
        'selected_role': role,
        'selected_status': status,
        'page_title': 'User Management',
    }
    return render(request, 'admin/users/list.html', context)


@admin_required
def admin_user_detail(request, pk):
    user_obj = get_object_or_404(User, pk=pk)
    donations = user_obj.donations.all()
    resident_records = user_obj.resident_registrations.all()
    reported_missing = user_obj.reported_missing.all()

    context = {
        'u': user_obj,
        'donations': donations,
        'resident_records': resident_records,
        'reported_missing': reported_missing,
        'page_title': f'User Profile: {user_obj.username}',
    }
    return render(request, 'admin/users/detail.html', context)


@admin_required
def admin_user_toggle_status(request, pk):
    user_obj = get_object_or_404(User, pk=pk)
    if user_obj.pk == request.user.pk:
        messages.error(request, "You cannot deactivate your own administrative account.")
        return redirect('admin_users_list')

    if user_obj.user_status == 'ACTIVE':
        user_obj.user_status = 'INACTIVE'
        user_obj.is_active = False
    else:
        user_obj.user_status = 'ACTIVE'
        user_obj.is_active = True
    user_obj.save(update_fields=['user_status', 'is_active'])

    messages.info(request, f"User {user_obj.username} is now {user_obj.get_user_status_display()}.")
    return redirect('admin_users_list')


@admin_required
def admin_user_delete(request, pk):
    user_obj = get_object_or_404(User, pk=pk)
    if user_obj.pk == request.user.pk:
        messages.error(request, "You cannot delete your own administrative account.")
        return redirect('admin_users_list')

    username = user_obj.username
    user_obj.delete()
    messages.success(request, f"User account '{username}' deleted successfully.")
    return redirect('admin_users_list')


# ==========================================
# RESIDENT MANAGEMENT
# ==========================================

@admin_required
def admin_residents_list(request):
    query = request.GET.get('q', '').strip()
    camp_id = request.GET.get('camp', '').strip()
    status = request.GET.get('status', '').strip()

    residents = CampResident.objects.select_related('camp').all()
    if query:
        residents = residents.filter(
            Q(name__icontains=query) | Q(phone__icontains=query) | 
            Q(emergency_contact__icontains=query) | Q(medical_information__icontains=query)
        )
    if camp_id:
        residents = residents.filter(camp_id=camp_id)
    if status:
        residents = residents.filter(status=status)

    camps = ReliefCamp.objects.all()

    context = {
        'residents': residents,
        'camps': camps,
        'selected_camp': camp_id,
        'selected_status': status,
        'query': query,
        'page_title': 'Resident Management',
    }
    return render(request, 'admin/residents/list.html', context)


@admin_required
def admin_resident_create(request):
    form = CampResidentForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        resident = form.save()
        messages.success(request, f"Resident '{resident.name}' successfully registered at {resident.camp.name}.")
        return redirect('admin_residents_list')

    return render(request, 'admin/residents/form.html', {
        'form': form,
        'action_title': 'Register New Camp Resident',
        'page_title': 'Add Camp Resident',
    })


@admin_required
def admin_resident_edit(request, pk):
    resident = get_object_or_404(CampResident, pk=pk)
    form = CampResidentForm(request.POST or None, instance=resident)
    if request.method == 'POST' and form.is_valid():
        resident = form.save()
        messages.success(request, f"Resident record for '{resident.name}' updated successfully.")
        return redirect('admin_residents_list')

    return render(request, 'admin/residents/form.html', {
        'form': form,
        'resident': resident,
        'action_title': f'Edit Resident: {resident.name}',
        'page_title': 'Edit Resident',
    })


@admin_required
def admin_resident_update_status(request, pk, new_status):
    resident = get_object_or_404(CampResident, pk=pk)
    if new_status in ['APPROVED', 'DISCHARGED', 'PENDING']:
        if new_status == 'APPROVED' and resident.status != 'APPROVED':
            if resident.camp.occupancy >= resident.camp.capacity:
                messages.error(
                    request, 
                    f"Cannot approve resident: Camp '{resident.camp.name}' is already at maximum capacity ({resident.camp.capacity})."
                )
                return redirect('admin_residents_list')
        
        resident.status = new_status
        resident.save()
        messages.success(request, f"Resident '{resident.name}' status updated to {resident.get_status_display()}.")
    return redirect('admin_residents_list')


@admin_required
def admin_resident_delete(request, pk):
    resident = get_object_or_404(CampResident, pk=pk)
    name = resident.name
    resident.delete()
    messages.success(request, f"Resident record for '{name}' removed.")
    return redirect('admin_residents_list')


# ==========================================
# RESOURCE & INVENTORY MANAGEMENT
# ==========================================

@admin_required
def admin_resources_list(request):
    camp_id = request.GET.get('camp', '').strip()
    status = request.GET.get('status', '').strip()

    requirements = ResourceRequirement.objects.select_related('camp').all()
    inventory = ResourceInventory.objects.select_related('camp').all()

    if camp_id:
        requirements = requirements.filter(camp_id=camp_id)
        inventory = inventory.filter(camp_id=camp_id)
    if status:
        requirements = requirements.filter(status=status)

    camps = ReliefCamp.objects.all()

    context = {
        'requirements': requirements,
        'inventory': inventory,
        'camps': camps,
        'selected_camp': camp_id,
        'selected_status': status,
        'page_title': 'Resource & Inventory Management',
    }
    return render(request, 'admin/resources/list.html', context)


@admin_required
def admin_resource_create(request):
    form = ResourceRequirementForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        req = form.save()
        messages.success(request, f"Requirement for '{req.resource_name}' posted for {req.camp.name}.")
        return redirect('admin_resources_list')

    return render(request, 'admin/resources/form.html', {
        'form': form,
        'action_title': 'Post Resource Requirement',
        'page_title': 'Add Resource Requirement',
    })


@admin_required
def admin_resource_edit(request, pk):
    req = get_object_or_404(ResourceRequirement, pk=pk)
    form = ResourceRequirementForm(request.POST or None, instance=req)
    if request.method == 'POST' and form.is_valid():
        req = form.save()
        messages.success(request, f"Resource requirement for '{req.resource_name}' updated.")
        return redirect('admin_resources_list')

    return render(request, 'admin/resources/form.html', {
        'form': form,
        'requirement': req,
        'action_title': f'Edit Resource Requirement: {req.resource_name}',
        'page_title': 'Edit Resource Requirement',
    })


@admin_required
def admin_resource_delete(request, pk):
    req = get_object_or_404(ResourceRequirement, pk=pk)
    name = req.resource_name
    req.delete()
    messages.success(request, f"Resource requirement for '{name}' deleted.")
    return redirect('admin_resources_list')


# ==========================================
# DONATION MANAGEMENT
# ==========================================

@admin_required
def admin_donations_list(request):
    status = request.GET.get('status', '').strip()
    camp_id = request.GET.get('camp', '').strip()

    donations = Donation.objects.select_related('camp', 'donor', 'verified_by').all()
    if status:
        donations = donations.filter(status=status)
    if camp_id:
        donations = donations.filter(camp_id=camp_id)

    camps = ReliefCamp.objects.all()

    context = {
        'donations': donations,
        'camps': camps,
        'selected_status': status,
        'selected_camp': camp_id,
        'page_title': 'Donation Verification & Management',
    }
    return render(request, 'admin/donations/list.html', context)


@admin_required
def admin_donation_verify(request, pk):
    """
    Verify donation atomically: updates resource received quantity and inventory.
    """
    donation = get_object_or_404(Donation, pk=pk)
    success, msg = donation.verify(request.user)
    if success:
        messages.success(request, msg)
    else:
        messages.warning(request, msg)
    return redirect('admin_donations_list')


@admin_required
def admin_donation_reject(request, pk):
    donation = get_object_or_404(Donation, pk=pk)
    if donation.status == 'VERIFIED':
        messages.error(request, "Cannot reject an already verified donation.")
        return redirect('admin_donations_list')

    donation.status = 'REJECTED'
    donation.save(update_fields=['status'])
    messages.info(request, f"Donation #{donation.id} has been marked as Rejected.")
    return redirect('admin_donations_list')


@admin_required
def admin_donation_mark_delivered(request, pk):
    donation = get_object_or_404(Donation, pk=pk)
    donation.status = 'DELIVERED'
    donation.save(update_fields=['status'])
    messages.success(request, f"Donation #{donation.id} marked as Delivered to {donation.camp.name}.")
    return redirect('admin_donations_list')


# ==========================================
# MISSING PERSON MANAGEMENT
# ==========================================

@admin_required
def admin_missing_persons_list(request):
    query = request.GET.get('q', '').strip()
    status = request.GET.get('status', '').strip()

    persons = MissingPerson.objects.all()
    if query:
        persons = persons.filter(
            Q(name__icontains=query) | Q(last_known_location__icontains=query) |
            Q(reporter_name__icontains=query)
        )
    if status:
        persons = persons.filter(status=status)

    context = {
        'persons': persons,
        'query': query,
        'selected_status': status,
        'page_title': 'Missing Persons Management',
    }
    return render(request, 'admin/missing_persons/list.html', context)


@admin_required
def admin_missing_person_detail(request, pk):
    person = get_object_or_404(MissingPerson, pk=pk)
    return render(request, 'admin/missing_persons/detail.html', {
        'person': person,
        'page_title': f'Report Detail: {person.name}',
    })


@admin_required
def admin_missing_person_update_status(request, pk, new_status):
    person = get_object_or_404(MissingPerson, pk=pk)
    if new_status in ['MISSING', 'LOCATED', 'VERIFIED']:
        person.status = new_status
        person.save(update_fields=['status', 'updated_at'])
        messages.success(request, f"Missing person report for '{person.name}' marked as {person.get_status_display()}.")
    return redirect('admin_missing_persons_list')


@admin_required
def admin_missing_person_delete(request, pk):
    person = get_object_or_404(MissingPerson, pk=pk)
    name = person.name
    person.delete()
    messages.success(request, f"Report for '{name}' deleted.")
    return redirect('admin_missing_persons_list')


# ==========================================
# NOTIFICATIONS & BROADCASTS
# ==========================================

@admin_required
def admin_notifications_list(request):
    notifications = Notification.objects.select_related('user').order_by('-created_at')
    return render(request, 'admin/notifications/list.html', {
        'notifications': notifications,
        'page_title': 'Broadcasts & Notifications',
    })


@admin_required
def admin_notification_create(request):
    form = NotificationForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        notif = form.save()
        recipient_text = notif.user.username if notif.user else "ALL CITIZENS (Global Broadcast)"
        messages.success(request, f"Notification broadcasted to {recipient_text}.")
        return redirect('admin_notifications_list')

    return render(request, 'admin/notifications/form.html', {
        'form': form,
        'page_title': 'Broadcast New Announcement / Notification',
    })


@admin_required
def admin_notification_delete(request, pk):
    notif = get_object_or_404(Notification, pk=pk)
    notif.delete()
    messages.success(request, "Notification deleted.")
    return redirect('admin_notifications_list')


# ==========================================
# REPORTS & ANALYTICS
# ==========================================

@admin_required
def admin_reports(request):
    """
    Consolidated administrative reports with filters.
    """
    camp_id = request.GET.get('camp', '')
    
    camps = ReliefCamp.objects.all()
    filtered_camps = camps
    if camp_id:
        filtered_camps = camps.filter(pk=camp_id)

    # Camp occupancy summary
    camp_reports = []
    for c in filtered_camps:
        camp_reports.append({
            'camp': c,
            'capacity': c.capacity,
            'occupancy': c.occupancy,
            'remaining': c.remaining_capacity,
            'occupancy_pct': c.occupancy_percentage,
            'status': c.get_status_display(),
        })

    # Resource requirements summary
    req_query = ResourceRequirement.objects.select_related('camp')
    if camp_id:
        req_query = req_query.filter(camp_id=camp_id)
    resource_reports = req_query.all()

    # Donation summary
    donation_stats = {
        'total': Donation.objects.count(),
        'verified': Donation.objects.filter(status='VERIFIED').count(),
        'pending': Donation.objects.filter(status='PENDING').count(),
        'delivered': Donation.objects.filter(status='DELIVERED').count(),
        'rejected': Donation.objects.filter(status='REJECTED').count(),
    }

    # Missing persons summary
    missing_stats = {
        'total': MissingPerson.objects.count(),
        'missing': MissingPerson.objects.filter(status='MISSING').count(),
        'located': MissingPerson.objects.filter(status='LOCATED').count(),
        'verified': MissingPerson.objects.filter(status='VERIFIED').count(),
    }

    context = {
        'camps': camps,
        'selected_camp': camp_id,
        'camp_reports': camp_reports,
        'resource_reports': resource_reports,
        'donation_stats': donation_stats,
        'missing_stats': missing_stats,
        'generated_at': timezone.now(),
        'page_title': 'Administrative Disaster Relief Reports',
    }
    return render(request, 'admin/reports/index.html', context)


@admin_required
def admin_reports_printable(request):
    """
    Printable format for academic evaluation, project review, and viva presentation.
    """
    camps = ReliefCamp.objects.all()
    requirements = ResourceRequirement.objects.select_related('camp').all()
    donations = Donation.objects.select_related('camp').all()[:50]
    residents = CampResident.objects.select_related('camp').all()[:50]
    missing = MissingPerson.objects.all()

    context = {
        'camps': camps,
        'requirements': requirements,
        'donations': donations,
        'residents': residents,
        'missing': missing,
        'generated_at': timezone.now(),
        'page_title': 'AidBridge Official Relief Audit Report',
    }
    return render(request, 'admin/reports/printable.html', context)
