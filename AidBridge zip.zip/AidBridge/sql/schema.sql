-- ==============================================================================
-- AidBridge: Post-Disaster Relief Camp & Resource Management Portal
-- Relational Database DDL Schema (PostgreSQL Compatible)
-- Master of Computer Applications (MCA) Mini Project
-- ==============================================================================

-- Drop tables if re-executing
DROP TABLE IF EXISTS core_notification CASCADE;
DROP TABLE IF EXISTS core_missingperson CASCADE;
DROP TABLE IF EXISTS core_donation CASCADE;
DROP TABLE IF EXISTS core_resourceinventory CASCADE;
DROP TABLE IF EXISTS core_resourcerequirement CASCADE;
DROP TABLE IF EXISTS core_campresident CASCADE;
DROP TABLE IF EXISTS core_reliefcamp CASCADE;
DROP TABLE IF EXISTS core_user CASCADE;

-- 1. Users Table (Administrators and Citizens)
CREATE TABLE core_user (
    id BIGSERIAL PRIMARY KEY,
    username VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(128) NOT NULL,
    first_name VARCHAR(150) NOT NULL DEFAULT '',
    last_name VARCHAR(150) NOT NULL DEFAULT '',
    email VARCHAR(254) NOT NULL UNIQUE,
    phone VARCHAR(20),
    address TEXT,
    role VARCHAR(10) NOT NULL DEFAULT 'CITIZEN' CHECK (role IN ('ADMIN', 'CITIZEN')),
    user_status VARCHAR(10) NOT NULL DEFAULT 'ACTIVE' CHECK (user_status IN ('ACTIVE', 'INACTIVE')),
    is_staff BOOLEAN NOT NULL DEFAULT FALSE,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    is_superuser BOOLEAN NOT NULL DEFAULT FALSE,
    last_login TIMESTAMPTZ,
    date_joined TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_user_role ON core_user (role);
CREATE INDEX idx_user_status ON core_user (user_status);

-- 2. Relief Camps Table
CREATE TABLE core_reliefcamp (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    address TEXT NOT NULL,
    district VARCHAR(100) NOT NULL,
    state VARCHAR(100) NOT NULL DEFAULT 'Kerala',
    latitude NUMERIC(9, 6) NOT NULL,
    longitude NUMERIC(9, 6) NOT NULL,
    capacity INT NOT NULL CHECK (capacity > 0),
    occupancy INT NOT NULL DEFAULT 0 CHECK (occupancy >= 0 AND occupancy <= capacity),
    contact VARCHAR(50) NOT NULL,
    facilities TEXT NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'FULL', 'INACTIVE')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_camp_district ON core_reliefcamp (district);
CREATE INDEX idx_camp_status ON core_reliefcamp (status);

-- 3. Camp Residents Table (Sheltered Disaster Victims)
CREATE TABLE core_campresident (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT REFERENCES core_user (id) ON DELETE SET NULL,
    camp_id BIGINT NOT NULL REFERENCES core_reliefcamp (id) ON DELETE CASCADE,
    name VARCHAR(150) NOT NULL,
    age INT NOT NULL CHECK (age >= 0 AND age <= 120),
    gender VARCHAR(10) NOT NULL CHECK (gender IN ('Male', 'Female', 'Other')),
    phone VARCHAR(20),
    emergency_contact VARCHAR(100) NOT NULL,
    address TEXT,
    medical_information TEXT,
    status VARCHAR(20) NOT NULL DEFAULT 'APPROVED' CHECK (status IN ('PENDING', 'APPROVED', 'DISCHARGED')),
    registered_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_resident_camp ON core_campresident (camp_id);
CREATE INDEX idx_resident_status ON core_campresident (status);

-- 4. Resource Requirements Table (Supplies Needed Per Camp)
CREATE TABLE core_resourcerequirement (
    id BIGSERIAL PRIMARY KEY,
    camp_id BIGINT NOT NULL REFERENCES core_reliefcamp (id) ON DELETE CASCADE,
    resource_name VARCHAR(150) NOT NULL,
    required_quantity NUMERIC(10, 2) NOT NULL CHECK (required_quantity > 0),
    received_quantity NUMERIC(10, 2) NOT NULL DEFAULT 0.00 CHECK (received_quantity >= 0),
    unit VARCHAR(50) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'URGENT' CHECK (status IN ('URGENT', 'MODERATE', 'FULFILLED')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_req_camp ON core_resourcerequirement (camp_id);
CREATE INDEX idx_req_status ON core_resourcerequirement (status);

-- 5. Resource Inventory Table (Available Physical Stock)
CREATE TABLE core_resourceinventory (
    id BIGSERIAL PRIMARY KEY,
    camp_id BIGINT NOT NULL REFERENCES core_reliefcamp (id) ON DELETE CASCADE,
    resource_name VARCHAR(150) NOT NULL,
    available_quantity NUMERIC(10, 2) NOT NULL DEFAULT 0.00 CHECK (available_quantity >= 0),
    unit VARCHAR(50) NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_camp_resource UNIQUE (camp_id, resource_name)
);

CREATE INDEX idx_inventory_camp ON core_resourceinventory (camp_id);

-- 6. Donations Table
CREATE TABLE core_donation (
    id BIGSERIAL PRIMARY KEY,
    donor_id BIGINT REFERENCES core_user (id) ON DELETE SET NULL,
    camp_id BIGINT NOT NULL REFERENCES core_reliefcamp (id) ON DELETE CASCADE,
    resource_requirement_id BIGINT REFERENCES core_resourcerequirement (id) ON DELETE SET NULL,
    resource_name VARCHAR(150) NOT NULL,
    quantity NUMERIC(10, 2) NOT NULL CHECK (quantity > 0),
    unit VARCHAR(50) NOT NULL DEFAULT 'units',
    donor_name VARCHAR(150),
    donor_phone VARCHAR(20),
    message TEXT,
    status VARCHAR(20) NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING', 'VERIFIED', 'REJECTED', 'DELIVERED')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    verified_at TIMESTAMPTZ,
    verified_by_id BIGINT REFERENCES core_user (id) ON DELETE SET NULL
);

CREATE INDEX idx_donation_status ON core_donation (status);
CREATE INDEX idx_donation_camp ON core_donation (camp_id);

-- 7. Missing Persons Table
CREATE TABLE core_missingperson (
    id BIGSERIAL PRIMARY KEY,
    reporter_id BIGINT REFERENCES core_user (id) ON DELETE SET NULL,
    reporter_name VARCHAR(150) NOT NULL,
    reporter_phone VARCHAR(20) NOT NULL,
    name VARCHAR(150) NOT NULL,
    age INT NOT NULL CHECK (age >= 0 AND age <= 120),
    gender VARCHAR(10) NOT NULL CHECK (gender IN ('Male', 'Female', 'Other')),
    last_known_location VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    photo VARCHAR(100),
    status VARCHAR(20) NOT NULL DEFAULT 'MISSING' CHECK (status IN ('MISSING', 'LOCATED', 'VERIFIED')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_missing_status ON core_missingperson (status);

-- 8. Notifications & Broadcasts Table
CREATE TABLE core_notification (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT REFERENCES core_user (id) ON DELETE CASCADE,
    title VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    notification_type VARCHAR(30) NOT NULL DEFAULT 'GENERAL' 
        CHECK (notification_type IN ('ANNOUNCEMENT', 'DONATION', 'CAMP_UPDATE', 'RESIDENT_STATUS', 'GENERAL')),
    is_read BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_notif_user ON core_notification (user_id);
CREATE INDEX idx_notif_type ON core_notification (notification_type);
