# PROJECT DOCUMENTATION
## AidBridge: Post-Disaster Relief Camp & Resource Management Portal
**Master of Computer Applications (MCA) Mini-Project**

---

### 1. ABSTRACT
Natural disasters such as floods, landslides, and cyclones cause severe physical destruction and displace thousands of vulnerable families. The post-disaster recovery phase presents profound humanitarian challenges: shelter allocation, medical emergency support, essential supplies distribution, and locating missing persons. Traditional methods rely on decentralized, manual, and unverified data, often resulting in shelter overcrowding, resource duplication, and delayed aid delivery.

**AidBridge** is a web-based post-disaster relief camp and resource management system designed specifically for the post-disaster recovery phase. The platform bridges relief administrators, shelter supervisors, affected citizens, and donors. Developed in Python and Django with PostgreSQL/SQLite, it provides real-time automated camp capacity enforcement, mathematical proximity discovery using the Haversine formula, transparent supply deficit calculation, atomic donation verification, and missing persons tracing.

---

### 2. INTRODUCTION
Disaster management consists of four core phases: mitigation, preparedness, response, and recovery. While early warning and rescue operations address immediate survival, the **post-disaster recovery phase** demands sustained coordination to provide food, potable water, medical attention, and temporary shelter to displaced populations.

AidBridge addresses this critical operational phase by offering a centralized coordination infrastructure. It eliminates information asymmetries between camp managers and external donors, ensuring that every relief contribution directly offsets documented shortages.

---

### 3. PROBLEM STATEMENT
Current post-disaster coordination exhibits the following limitations:
1. **Capacity Blindness**: Relief shelters lack real-time visibility into bed occupancy, resulting in certain camps being overcrowded beyond safe limits while others remain underutilized.
2. **Resource Misallocation**: Donors lack visibility into exact shortages, leading to surplus donations of perishable foods while urgent medical and infant supplies remain unfulfilled.
3. **Double Verification & Fraud**: Uncoordinated item donation pipelines can double-count pledges or log fictitious contributions.
4. **Information Isolation for Displaced Persons**: Affected citizens lack accessible digital tools to find the closest open shelters with available spaces based on their live GPS coordinates.
5. **Fragmented Missing-Person Records**: Information about separated family members is scattered across unvetted social media posts rather than an official, verified directory.

---

### 4. OBJECTIVES
1. **Camp Operations**: Enable administrators to establish, monitor, and regulate relief camps with automatic vacancy calculation (`Remaining = Maximum Capacity - Current Occupancy`).
2. **Victim Admission**: Streamline victim shelter admissions while tracking critical medical conditions (e.g., diabetes, asthma, pregnancy).
3. **Supply Deficit Transparency**: Post item-level targets and automatically track received quantities and remaining deficits (`Shortage = Required - Received`).
4. **Atomic Stock Verification**: Atomically increment available physical inventory upon administrator verification, ensuring data integrity.
5. **Geolocation Discovery**: Implement the **Haversine Distance Formula** to rank shelters by proximity to the citizen's GPS coordinates.
6. **Missing Persons Bureau**: Maintain an official case registry to verify reports and record reunited individuals.
7. **Emergency Broadcasts**: Provide immediate situational advisories via public banner tickers and targeted notices.

---

### 5. EXISTING SYSTEM VS. PROPOSED SYSTEM

| Parameter | Existing System | Proposed AidBridge System |
| :--- | :--- | :--- |
| **Data Recording** | Paper registers and spreadsheets | Centralized relational database |
| **Capacity Tracking** | Manual headcounts prone to errors | Automated real-time capacity and occupancy meter |
| **Resource Needs** | Uncoordinated public appeals | Live supply targets with deficit progress bars |
| **Donation Auditing** | Unverified informal drop-offs | Atomic verification crediting camp physical inventory |
| **Shelter Discovery** | Word of mouth and broadcast radio | GPS-based Haversine proximity distance calculation |
| **Missing Persons** | Ad-hoc social media posts | Verified bureau with public-safe records and status |
| **Reporting** | Delayed manual summaries | Real-time audit reports with printable official format |

---

### 6. FUNCTIONAL REQUIREMENTS

#### 6.1 Administrator Module
- **Authentication**: Secure role-based login and session management.
- **Executive Dashboard**: Real-time aggregated statistics from the database (users, camps, residents, donations, inventory, shortages, missing persons) alongside Chart.js visual graphs.
- **Relief Camp Management**: Full CRUD operations for shelters, GPS coordinates, facilities, and statuses (Active, Full, Inactive).
- **Resident Management**: Victim admissions, camp allocation with capacity guards, medical alerts, and discharge processing.
- **Resource & Stock Control**: Post camp-level supply requirements, monitor shortages, and track on-hand physical stock.
- **Donation Verification**: Atomic verification crediting inventory and updating requirements while preventing duplicate processing.
- **Missing Persons Bureau**: Review case reports, verify identities, and update statuses to Located/Reunited.
- **Notifications**: Issue global announcements and direct user notices.
- **Audit Reports**: Tabular reports with filtering and a print-optimized PDF layout.

#### 6.2 Citizen / Public Module
- **Public Directory**: Browse shelters, filter by district, and sort by proximity using device GPS coordinates.
- **Resource Transparency**: View live item shortages and review camp drop-off details.
- **Missing Persons Search**: Public-safe search by name, age, gender, and last known location.
- **User Authentication**: Secure citizen registration and login.
- **Disaster Bulletins**: View real-time disaster alerts and urgent calls.

---

### 7. NON-FUNCTIONAL REQUIREMENTS
1. **Data Integrity & Consistency**: Enforce foreign keys, check constraints, and atomic database transactions (`transaction.atomic`).
2. **Security**: Strong password hashing using PBKDF2/SHA256, CSRF token verification on all forms, SQL injection prevention via Django ORM, and role-based access control.
3. **Performance & Scalability**: Indexed query paths on frequently searched fields (e.g., district, status, role).
4. **Usability & Responsiveness**: Mobile-first responsive layout built with Bootstrap 5.3 and intuitive disaster-relief visual hierarchy.
5. **Zero External API Cost**: Implemented mathematical Haversine calculations directly in Python and JavaScript without requiring paid third-party mapping APIs.

---

### 8. SYSTEM ARCHITECTURE

```
+-------------------------------------------------------------+
|                     Client Browser Layer                    |
|      (HTML5, CSS3, Bootstrap 5.3, JavaScript, Chart.js)     |
+------------------------------+------------------------------+
                               | HTTP / HTTPS Requests
                               v
+-------------------------------------------------------------+
|                     Django Web Framework                    |
|  +---------------------+  +-------------------------------+  |
|  |  Middleware Layer   |  |   URL Routing (urls.py)       |  |
|  |  (Auth, CSRF, Msg)  |  +---------------+---------------+  |
|  +---------------------+                  |                  |
|                                           v                  |
|  +--------------------------------------------------------+  |
|  |                      View Layer                        |  |
|  |  - Public Views (views.py)                             |  |
|  |  - Administrative Views (admin_views.py)               |  |
|  +---------------------------+----------------------------+  |
|                              |                               |
|                              v                               |
|  +--------------------------------------------------------+  |
|  |                 Business Logic & Forms                 |  |
|  |  - forms.py (Validation, capacity checks)              |  |
|  |  - utils.py (Haversine formula, metrics aggregator)    |  |
|  +---------------------------+----------------------------+  |
|                              |                               |
|                              v                               |
|  +--------------------------------------------------------+  |
|  |                   Django ORM Models                    |  |
|  |  - User, ReliefCamp, CampResident                      |  |
|  |  - ResourceRequirement, ResourceInventory              |  |
|  |  - Donation, MissingPerson, Notification               |  |
|  +---------------------------+----------------------------+  |
+------------------------------|-------------------------------+
                               | SQL Queries (ACID Transactions)
                               v
+-------------------------------------------------------------+
|                       Database Layer                        |
|        PostgreSQL (Production) / SQLite3 (Development)      |
+-------------------------------------------------------------+
```

---

### 9. DATABASE DESIGN & ENTITY RELATIONSHIPS

#### Core Entities:
1. **`User`**: Custom user extending `AbstractUser` with attributes `role` (`ADMIN`, `CITIZEN`), `phone`, `address`, and `user_status`.
2. **`ReliefCamp`**: Master entity tracking name, GPS coordinates (`latitude`, `longitude`), `capacity`, `occupancy`, facilities, and status (`ACTIVE`, `FULL`, `INACTIVE`).
3. **`CampResident`**: Sheltered victims linked via foreign key to `ReliefCamp`, capturing personal details, emergency contacts, medical notes, and status (`PENDING`, `APPROVED`, `DISCHARGED`).
4. **`ResourceRequirement`**: Camp-level supply deficit target (`required_quantity`, `received_quantity`, `unit`, `status`).
5. **`ResourceInventory`**: Physical on-hand stock linked to `ReliefCamp` and unique item name.
6. **`Donation`**: Pledged contributions linked to `ReliefCamp`, `ResourceRequirement`, and optional `User`. Supports atomic verification.
7. **`MissingPerson`**: Case records including name, age, gender, last known location, photo, reporter contact details, and status (`MISSING`, `LOCATED`, `VERIFIED`).
8. **`Notification`**: Broadcast bulletins and user notifications.

---

### 10. FUTURE ENHANCEMENTS
1. **SMS Gateway Integration**: Cellular SMS dispatch for areas with intermittent mobile data.
2. **Volunteer Skill Matching**: Module to register and deploy medical doctors, search volunteers, and civil engineers.
3. **Offline Progressive Web App (PWA)**: Offline caching of camp lists and emergency numbers for remote disaster areas.
4. **Drone Logistics Integration**: Automatic routing and dispatch logs for drone delivery of essential medicines to cut-off camps.
